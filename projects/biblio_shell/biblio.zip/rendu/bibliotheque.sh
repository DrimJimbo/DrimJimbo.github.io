#!/bin/bash
source ./lib_functions.sh #import fichier functions
# Recuperation du fichier_data
[ "$1" == "-h" ] && help_function && exit 1
read -rp "Fichier data : " fichier_data
bool=0
while [ "$bool" -eq 0 ]
do
	extent=$(extension "$fichier_data") #verification de l'extension
	if [ "$extent" -eq 0 ] ; then
		echo "Mauvaise extension de fichier !"
	fi
	if [ -f "$fichier_data" ] ; then
		bool=1
	else 
		echo "le fichier n'existe pas !"
		read -rp "Fichier data : " fichier_data
	fi
done
#Recuperation du fuchier_emprunts
read -rp "Fichier d'emprunts : " fichier_emprunts
bool=0
while [ "$bool" -eq 0 ]
do
	extent=$(extension "$fichier_emprunts") #verification de l'extension
	if [ "$extent" -eq 0 ] ; then
		echo "Mauvaise extension de fichier !"
	fi
	if [ -f "$fichier_emprunts" ] ; then
		bool=1
	else 
		echo "le fichier n'existe pas !"
		read -rp "Fichier d'emprunts : " fichier_emprunts
	fi
done
#Debut main
make_backup
clear
display
menu=""
script=""
while [ "$script" != "exit" ]
do
	read -rp "Commande : " script
	#si l'utilisateur n'a pas choisis de menu
	if [ "$menu" == "" ]
	then
		menu=$(choice_menu "$script")
	else 
		num=$(echo "$menu" | cut -d"|" -f2) #recupere le numéro du retour
		if [ "$script" == "retour" ] ; then
			menu=$(choice_menu "$script")
		fi
		if [ "$script" == "$num" ] ; then
			menu=$(choice_menu "retour")
		else 
			launch "$script" "$menu" "$fichier_data" "$fichier_emprunts" #lance la commande demande par l'utilisateur
		fi
	fi
	echo
done
