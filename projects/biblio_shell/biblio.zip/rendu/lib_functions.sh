#!/bin/bash
# le visuel a été créer par la commande suivante : figlet BU Lens | boxes -d scroll
visuel=" / ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ \\
|  /~~\                                         /~~\  |
|\ \   |   ____  _   _   _                     |   / /|
| \   /|  | __ )| | | | | |    ___ _ __  ___   |\   / |
|  ~~  |  |  _ \| | | | | |   / _ \ '_ \/ __|  |  ~~  |
|      |  | |_) | |_| | | |__|  __/ | | \__ \  |      |
|      |  |____/ \___/  |_____\___|_| |_|___/  |      |
|      |                                       |      |
|      |                                       |      |
 \     |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|     /
  \   /                                         \   /
   ~~~                                           ~~~"

# Vérifie l'extension du fichier, 1 si csv ou txt sinon 0
extension () {
	exten=$(echo "$1" | grep -E '\.txt') #recupere l'extension txt
	[ "$exten" != "" ] && echo "1" && exit 1 
	exten=$(echo "$1" | grep -E '\.csv') #recupere extension csv
	[ "$exten" != "" ] && echo "1" && exit 2
	echo "0"
}
########################################## Affichage ##########################################
# affichage principal 
display () {
	
	echo "$visuel"
	echo 
	echo "    (1)gestion_des_livres        (2)recherche_et_filtres"
	echo "    (3)statistiques_et_rapport   (4)emprunts"
	echo
}

# affichage gestion_des_livres
display_gestion () {
	echo
	echo "$visuel"
	echo
	echo "    (1)ajouter_livre    (2)supprimer_livre"
	echo "    (3)modifier_livre   (4)afficher_livre"
	echo "    (5)retour"
}

# affichage recherche_et_filtres
display_recherche () {
	echo
	echo "$visuel"
	echo
	echo "    (1)r_auteur    (2)r_titre    (3)r_avancer"
	echo "    (4)f_genre     (5)f_annee"
	echo "    (6)retour"
}

# affichage statistique_et_rapport
display_stat () {
	echo
	echo "$visuel"
	echo
	echo "    (1)nb_livres    (2)genre    (3)top_cinq"
	echo "    (4)decennie     (5)export"
	echo "    (6)retour"
}

# affichage emprunts
display_emprunts () {
	echo
	echo "$visuel"
	echo
	echo "    (1)emprunter_livre    (2)retourner_livre    (3)lister_livre_emprunter"
	echo "    (4)retard             (5)historique         (6)retour"
}

########################################## Fonctions Principales ##########################################
#permet le choix du menu 
choice_menu () {
	case "$1" in 
		"1"|"gestion_des_livres")display_gestion >&2 ; echo "gestion|5";;
		"2"|"recherche_et_filtres")display_recherche >&2 ; echo "recherche|6";;
		"3"|"statistiques_et_rapport")display_stat >&2 ; echo "stat|6";;
		"4"|"emprunts")display_emprunts >&2 ; echo "emprunts|6";;
		"clear") clear >&2 && display >&2 && echo "";; 
		"help") help_function >&2 && echo "";;
		"retour")display >&2;echo "";;
		*) echo "Commande Introuvable !" >&2 ; echo "";;
	esac
}

# Fonction faisant une backup des données
# Les données sont dans un dossier compréssé avec à l'intérieur une copie de tout les fichier .txt
# Le dossier compressé est à la date du jour, si une backup à déjà été faite, celle ci est écrasée.
make_backup() {
	src="./backups"
	title="backup_$(date +"%d_%m_%Y")"
	
	echo "Backup quotidienne en cours..."
	#Si une backup a déjà été faite aujourd'hui, on l'ecrase
	if [ -d "$src/$title" ]; then
		echo "Une backup a déjà été faite, on écrase son contenu si des modifications on été faites."
	else 
		echo "Pas de backup faite aujourd'hui, on créer une backup."
		mkdir "$src/$title"
	fi

	/bin/cp -ru ./*.txt "$src/$title"
}

help_function () {
	echo "Utilisation de bibliothéque : ./bibliotheque.sh"
	echo "Chaque fonctions/menu peut être accessible via leur numéros ou leur nom."
	echo "Exemple : entrez dans le menu des gestions"
	echo "         Commande : gestion_des_livres" 
	echo "                    ou"
	echo "         Commande : 1"
	echo "Les commandes 'exit', 'clear' et 'help' sont disponible dans chaque menu !" 
}

#lance la commande demandée param:script/menu/fichier_data/fichier_emprunt
launch () {
	nom=$(echo "$2" | cut -d"|" -f1) #récupère le nom du menu
	if [ "$nom" == "gestion" ]
	then
		case "$1" in
			"1"|"ajouter_livre") add_book "$3";;
			"2"|"supprimer_livre") delete_book "$3";;
			"3"|"modifier_livre") change_book "$3";;
			"4"|"afficher_livres") show_books "$3";;
			"clear") clear && display_gestion ;;
			"help") help_function;;
			"exit") exit 1;;
			*) echo "Commande Introuvable!";;
		esac
	fi
	if [ "$nom" == "recherche" ]
	then
		case "$1" in
			"1"|"r_auteur") search_by_author "$3";;
			"2"|"r_titre") search_by_title "$3";;
			"3"|"r_avancer") advanced_search "$3";;
			"4"|"f_genre") filter_by_genre "$3";;
			"5"|"f_annee") filter_by_year "$3";;
			"clear") clear && display_recherche ;;
			"help") help_function;;
			"exit") exit 1;;
			*) echo "Commande Introuvable!";;
		esac
	fi
	if [ "$nom" == "stat" ]
	then
		case "$1" in
			"1"|"nb_livres") show_nb_books "$3";;
			"2"|"genre") stats_gender "$3" | sort;;
			"3"|"top_cinq") top_five "$3";;
			"4"|"decennie") stats_books_decades "$3";;
			"5"|"export") export_data "$3";;
			"clear") clear && display_stat ;;
			"help") help_function;;
			"exit") exit 1;;
			*) echo "Commande Introuvable!";;
		esac
	fi
	if [ "$nom" == "emprunts" ]
	then
		case "$1" in
			"1"|"emprunter_livre") emprunter_livre "$3" "$4";;
			"2"|"retourner_livre") return_livre "$3" "$4";;
			"3"|"lister_livre_emprunter") list_livre_emprunte "$3";;
			"4"|"retard") retard_emprunt "$3" "$4";;
			"5"|"historique") emprunts_history "$4";;
			"clear") clear && display_emprunts ;;
			"help") help_function;;
			"exit") exit 1;;
			*) echo "Commande Introuvable!";;
		esac
	fi
}

#boucle pour lire l'id d'un livre
exist_book () {
	while true; do
        read -rp "Id du livre : " id
        [ "$id" == "exit" ] && echo "exit" && exit 1 #quitter la fonction si exit
        book=$(grep "^${id}|" "$1") # recherche l'id dans le fichier
        if [ -n "$book" ]; then # si len(book) est non nul
        	echo "$book"
            	break
        else
        	echo "Id inexistant!" >&2
        fi
    done
}
########################################## Gestions_des_livres ##########################################
# Fonction demandant quel est le titre du livre, et vérifie si le titre est conforme
ask_book_title() {
	title=""
	while [ -z "$title" ]; do # Si la chaîne est vide
        read -rp "    1- Quel est le titre du livre ? " title
        if [ -z "$title" ]; then
        	[ "$1" == "change" ] && exit 1
        	echo "Cette valeur n'est pas valide." >&2
        fi
    done
	echo "$title"
}

# Fonction demandant qui est l'auteur du livre, et vérifie si le nom de l'auteur est conforme
ask_book_author() {
	author=""
	while [ -z "$author" ]; do #Si la chaîne est vide
        read -rp "    2- Qui a ecrit le livre ? " author
        if [ -z "$author" ]; then
        	[ "$1" == "change" ] && exit 1
        	echo "Cette valeur n'est pas valide." >&2
        fi
    done
	echo "$author"
}

# Fonction demandant quand est sortie le livre, et vérifie si la date est au bon format
ask_book_date() {
	year=""
	current_year=$(date +%Y)  # récupère l'année actuelle
    while  ! [[ "$year" =~ ^[0-9]+$ ]] || [ "$year" -gt "$current_year" ]; do
        read -rp "    3- Quelle est l'année de publication ? " year
        [ "$1" == "change" ] && [ "$date" == "" ] && exit 1
        if ! [[ "$year" =~ ^[0-9]+$ ]]; then # +~ Compare la validité d'une expression par rapport à une ER
            echo "Veuillez entrer un nombre valide." >&2
        elif [ "$year" -gt "$current_year" ]; then # Si l'année est dans le futur
            echo "La date n'est pas valide." >&2 #Rediriger vers stderr pour récupérer uniquement la valeur de fin
        fi
    done
	echo "$year"
}

# Fonction demandant quel est le genre du livre.
ask_book_gender() {
	gender=""
	valid_value=0
    while [ "$valid_value" -eq 0 ]; do

        echo "    4- Quelle est le genre de votre livre ?" >&2 
        echo "        1) Roman" >&2 
        echo "        2) Nouvelle" >&2 
        echo "        3) Conte" >&2 
        echo "        4) Poésie" >&2 
        echo "        5) Théâtre" >&2 
        echo "        6) Essai" >&2 
        echo "        7) Biographie / Autobiographie" >&2 
        echo "        8) Récit de voyage" >&2 
        echo "        9) Autre" >&2 #Rediriger vers stderr pour récupérer uniquement la valeur de fin

        read -rp "    Choisissez un numéro : " choice
	[ "$choice" == "" ] && [ "$1" == "change" ] && exit 1
        case "$choice" in
            1) gender="Roman" ; valid_value=1;;
            2) gender="Nouvelle" ; valid_value=1;;
            3) gender="Conte" ; valid_value=1;;
            4) gender="Poésie" ; valid_value=1;;
            5) gender="Théâtre" ; valid_value=1;;
            6) gender="Essai" ; valid_value=1;;
            7) gender="Biographie / Autobiographie" ; valid_value=1;;
            8) gender="Récit de voyage" ; valid_value=1;;
            9) read -rp "Entrez un autre genre : " gender ; valid_value=1;;
            *) echo "Choix invalide." >&2 ; valid_value=0;; #Rediriger vers stderr pour récupérer uniquement la valeur de fin
        esac

        echo "    Vous avez choisi le genre : $gender" >&2 #Rediriger vers stderr pour récupérer uniquement la valeur de fin
        
    done
	echo "$gender"
}

#ajoute un livre au fichier des livres
add_book () { #ajouter_livre
    id=""
    title=""
    author=""
    year=""
    gender=""
    status="Disponible"
    
    echo "Vous souhaitez ajouter un livre à la bibliothèque, nous avons cependant besoin de quelques informations :"    
    echo "PS:L'ajout se fera sur le fichier \"$1\""
	title=$(ask_book_title)
	author=$(ask_book_author)
	year=$(ask_book_date)
	gender=$(ask_book_gender)

    id=1
    output=""
    found=0
    #On créé une copie temporaire du fichier
    cat "$1" > livre.txt
    #Pour chaque ligne du document livre.txt
    while read -r line; do

        line_id=$(echo "$line$" | grep -Eo "^[0-9]+")
        #Si c'est une ligne sans id on passe
        if [ -z "$line_id" ]; then continue; fi

        #Si on tombe sur une ligne ou l'id n'est pas censé être le bon, on peut inserer
        if ! [ "$id" -eq "$line_id" ]; then
            output="$id|$title|$author|$year|$gender|$status"
            found=1
            (sed -E "$((id+1)) i $output" < "$1") > livre.txt
            break
        else
            id=$((id+1))
        fi
    done < "$1"
    
    # Si le livre n'a pas été inséré, on le mets à la fin
    if [ "$found" -eq 0 ]; then
        output="$id|$title|$author|$year|$gender|$status"
        echo "$output" >> livre.txt
    fi

    # On copie la version temporaire dans la version définitive & on supprime le temporaire
    cat "livre.txt" > "$1"
    rm "livre.txt"

    echo ""
    echo "L'entrée :"
    echo "$output"
    echo "a bien été ajoutée."

	make_backup

}

# supprime un livre
delete_book () { #suprimer_livre
	book=$(exist_book "$1") # lance la recherche d'id
	[ "$book" == "exit" ] && return 1 # si exit est rentre on ferme la fonction
	echo "Voulez vous supprimer le livre suivant (O/n) : $book" 
	read -r awsner
	if [ "$awsner" == "O" ]
	then
		sed -i "/^${book}$/d" "$1" #suppression du livre
	fi

	make_backup
}

#modifie un livre
change_book () { #modifier_livre
	book=$(exist_book "$1") #lance la recherche d'id
	id=$(echo "$book" | cut -d"|" -f1) #recupere l'id du livre
	dispo=$(echo "$book" | cut -d "|" -f6) #recupere la dispo (car non changable avec cette fonction)
	echo "Voulez vous modifier le livre suivant (O/n) : $book" 
	read -r awsner
	if [ "$awsner" == "O" ]
	then
		echo "PS: Appuyer sur entre si vous ne voulez pas changer la catégorie."
		all=""
		titre=$(ask_book_title "change")
		[ "$titre" == "" ] && titre=$(echo "$book" | cut -d"|" -f2)
		auteur=$(ask_book_author "change")
		[ "$auteur" == "" ] && auteur=$(echo "$book" | cut -d"|" -f3)
		date=$(ask_book_date "change")
		[ "$date" == "" ] && date=$(echo "$book" | cut -d"|" -f4)
		genre=$(ask_book_gender "change")
		[ "$genre" == "" ] && genre=$(echo "$book" | cut -d"|" -f5)
		all="${id}|${titre}|${auteur}|${date}|${genre}|${dispo}"
		sed -i "s/^${book}$/${all}/" "$1"
	fi

	make_backup
}

#affichage des livres
show_books() { #afficher_livre

    local file="$1"
    local page_size=20
    local total_lines=$(wc -l < "$file")
    local current_line=1

    # Fonction interne d'affichage d'une page
    display_page() {
		current_page=$(((current_line/page_size)+1))
        total_pages=$(((total_lines+page_size-1)/page_size))
        clear
		if [[ $current_page -gt 1 ]]; then 
			echo "ID|Titre|Auteur|Date|Genre|Disponibilité"
		fi
        sed -n "${current_line},$((current_line + page_size - 1))p" "$file"

        echo $'\n' "Page $current_page/$total_pages"  $'\n'   #affichage de l'actuelle page/le nombre de pages totales

        echo "\"←\" Précédent | \"→\" Suivant | \"q\" Quitter"
    }

    # Afficher la première page
    display_page

    # Boucle de navigation
    while true; do

        read -rsn1 key
        if [[ $key == $'\x1b' ]]; then
            read -rsn2 key
            case $key in
                "[C")   # Flèche droite → page suivante
                    if (( current_line + page_size <= total_lines )); then
                        current_line=$((current_line + page_size))
                        display_page
                    fi
                    ;;
                "[D")   # Flèche gauche → page précédente
                    if (( current_line - page_size >= 1 )); then
                        current_line=$((current_line - page_size))
                    else
                        current_line=1
                    fi
                    display_page
                    ;;
            esac

        elif [[ $key == "q" ]]; then
            break
        fi
    done
	clear
	display_gestion >&2
}
########################################## Recherche_et_filtres ##########################################
#recherche par auteur
search_by_author() { #r_auteur
    local file="$1"
    read -p "Entrez le nom d'un auteur : " author_keyword
    echo "Livres dont l'auteur contient '$author_keyword' :"
    echo "---------------------------------------------"

    while IFS="|" read -r id title author year genre status; do
        if [[ "${author,,}" == *"${author_keyword,,}"* ]]; then
            printf "%-3s | %-30s | %-20s | %-4s | %-15s | %-12s\n" \
            "$id" "$title" "$author" "$year" "$genre" "$status"
        fi
    done < "$file"
}

#recherche par titre
search_by_title() { #r_titre
    local file="$1"
    read -p "Entrez un titre ou une partie d'un titre : " keyword
    echo "Résultats dont le titre contient '$keyword' :"
    echo "-------------------------------------------"

    while IFS="|" read -r id title author year genre status; do
        if [[ "${title,,}" == *"${keyword,,}"* ]]; then
            printf "%-3s | %-30s | %-20s | %-4s | %-15s | %-12s\n" \
            "$id" "$title" "$author" "$year" "$genre" "$status"
        fi
    done < "$file"
}

#recherche avancée (combinaison de plusieurs recherche)
advanced_search() { #r_avancer
    local file="$1"
    echo "=== Advanced Search ==="
    echo "(Laissez un paramètre vide si vous voulez l'ignorer)"
    echo

    read -p "Entrez un titre ou une partie de titre : " title_keyword
    read -p "Entrez un auteur : " author_keyword
    read -p "Entrez un genre spécifique : " genre_keyword
    read -p "Entrez une année de début : " min_year
    read -p "Entrez une année de fin : " max_year
    echo
    echo "Résultats en fonction de tous les critères :"
    echo "----------------------------------------"

    while IFS="|" read -r id title author year genre status; do
        ok=1
        [[ -n "$title_keyword"  && "${title,,}"  != *"${title_keyword,,}"* ]]  && ok=0
        [[ -n "$author_keyword" && "${author,,}" != *"${author_keyword,,}"* ]] && ok=0
        [[ -n "$genre_keyword"  && "${genre,,}"  != "${genre_keyword,,}" ]] && ok=0
        [[ -n "$min_year"       && "$year" -lt "$min_year" ]] && ok=0
        [[ -n "$max_year"       && "$year" -gt "$max_year" ]] && ok=0

        if (( ok )); then
            printf "%-3s | %-30s | %-20s | %-4s | %-15s | %-12s\n" \
            "$id" "$title" "$author" "$year" "$genre" "$status"
        fi
    done < "$file"
}

#recherche par genre
filter_by_genre() { #f_genre
    local file="$1"
    echo "Genre disponibles :"
    cut -d"|" -f5 "$file" | sort | uniq
    echo
    read -p "Entrez un des genres disponibles : " genre_keyword
    echo "Livres dans le genre '$genre_keyword':"
    echo "--------------------------------"

    grep -i "|$genre_keyword|" "$file" | while IFS="|" read -r id title author year genre status; do
        printf "%-3s | %-30s | %-20s | %-4s | %-15s | %-12s\n" \
        "$id" "$title" "$author" "$year" "$genre" "$status"
    done
}

#recherche par année de parrution
filter_by_year() { #f_annee
    local file="$1"
    read -p "Entrez une année de départ : " start_year
    read -p "Entrez une année de fin : " end_year
    echo "Livres publiés entre $start_year et $end_year : "
    echo "-------------------------------------"

    while IFS="|" read -r id title author year genre status; do
        if [[ "$year" -ge "$start_year" && "$year" -le "$end_year" ]]; then
            printf "%-3s | %-30s | %-20s | %-4s | %-15s | %-12s\n" \
            "$id" "$title" "$author" "$year" "$genre" "$status"
        fi
    done < "$file"
}

########################################## statistiques_et_rapport ##########################################
#nombre de livre dans le fichier
nb_book () { 
	number_book=$(cat "$1" | wc -l) #calcule le nombre de ligne
	echo $((number_book-1)) #-1 car la 1er ligne n'est pas un livre
}

#affiche le nombre de livre dans le fichier
show_nb_books() { #nb_livres
	echo "Nombre de livre dans la bibliothéque : $(nb_book "$1")"
}

# Fonction affichant la répartition des genres des livres
stats_gender() { #genre
	counts=""
	#Lecture de chaque ligne du document
	while read -r line; do
		gender=$(echo "$line" | sed -E "s/^.*\|.*\|.*\|(.*)\|.*/\1/") #On récupère le genre de la ligne
		in_counts=$(echo "$counts" | grep "$gender:") #On vérifie si le genre est dans counts

		if [ -z "$in_counts" ]; then #Si la recherche est une chaine vide
			counts=$(echo -e "$counts\n$gender:1")
		else
			old=$(echo "$in_counts" |grep -Eo "[0-9]+")
			new=$((old+1))
			counts=$(echo "$counts" | sed -E "s/$gender:([0-9]+)/$gender:$new/")
		fi
	done < "$1"

	echo "Voici la répartition des genres de la bibliothèque" >&2 # Redirection vers stderr pour pouvoir recupérér uniquement la sortie
	for gender in $counts; do
		count=$(echo "$gender" | sed -E "s/.*:(.*)/\1/")
		gender=$(echo "$gender" | sed -E "s/(.*):.*/\1/")
		printf "%-30s(%d) " "$gender" "$count"

		for book in $(seq "$count"); do
			printf "#"
		done
		printf "\n"
	done
}

#nombre de livre par auteur
book_by_author () {
	res=""
	nb_line=$(($(cat "$1" | wc -l)-1)) #nombre de ligne -1
	for i in $(seq 1 "$nb_line")
	do
		book=$(cat "$1" | tail -"$i" | head -1) #recupere la (nb_line-i+1)eme ligne du fichier | parcourt de bas en haut
		author=$(echo "$book" | cut -d"|" -f3) #recupere l'auteur
		exist=$(echo "$res" | grep -E "${author}") #verifie si le nom de l'auteur est deja dans res
		if [ "$exist" != "" ]
		then
			nb_author=$(($(echo "$exist" | cut -d"|" -f2)+1)) #livre +1 si il existe
			res=$(echo "$res" | sed "s/^${author}.*/${author}|${nb_author}/")
		else
			res="$res"$'\n'"$author|1" #livre=1 si pas existant
		fi
	done
	echo "$res"
}

#recherche le top auteur 
find_top () {
	nb_line=$(echo "$1" | wc -l)
	max="0"
	max_author=""
	for i in $(seq 1 "$nb_line")
	do
		nb_actuel=$(echo "$1" | tail -"$i" | head -1 | cut -d"|" -f2) # recupere le nombre de livre | parcpurs de bas en haut
		# si le nombre est supérieur au précédent recupere le nombre de livre et le nom de l'auteur
		[ "$nb_actuel" != "" ] && [ "$nb_actuel" -gt "$max" ] && max="$nb_actuel" && max_author=$(echo "$1" | tail -"$i" | head -1) 
	done
	echo "$max_author"
}

#affiche le top 5 des auteurs ayant le plus de livre (en cas d'egalite ce sont les auteur les plus bas du fichier qui sont afficher)
top_five () { #top_cinq
	res=$(book_by_author "$1")
	nb_line=5
	# verifie qu'il existe bien au moin 5 auteur sinon affiche uniquement les auteurs présent
	[ "$(echo "$res" | wc -l)" -lt 5 ] && nb_line=$(($(echo "$res" | wc -l)-1)) 
	author=""
	for i in $(seq 1 "$nb_line")
	do
		author=$(find_top "$res")
		res=$(echo "$res" | sed "/^${author}/d")
		echo "${i}. $author"
	done
}

# Fonction affichant la décénnie correspondant à l'année passé en paramètres
# get_decade 1898 -> 1890
get_decade() {
	echo $(( ("$1" / 10) * 10))
}

# Fonction affichant le nombre de livres par décennie
stats_books_decades() { #decennie
	decade_book=""
	empty=1
	# Lecture du document ligne par ligne
	while read -r line; do
		#On récupère l'année de sortie de livre et on prend à quel décénnie il appartient
		decade=$(echo "$line" | sed -E "s/^.*\|.*\|(.*)\|.*\|.*/\1/")
		if [ "$decade" = "Date" ]; then continue; fi;
		decade=$(get_decade "$decade")

		#On verifie si on a déjà des livres de cette décennie qui on été trouvés
		decade_exist=$(echo "$decade_book" | grep -E "$decade : [0-9]+ livre(s)?")

		#Si aucun livre de cette décénnie existe pour le moment
		if [ -z "$decade_exist" ]; then
			#Si c'est le tout premier livre on initialise decade_book
			if [ "$empty" -eq 1 ]; then
				decade_book="$decade : 1 livre"
				empty=0
			else #Sinon on l'ajoute à la fin du fichier
				decade_book=$(echo "$decade_book"; echo "$decade : 1 livre")
			fi

		else #Si un livre de cette décénnie a déjà été trouvé, on incrémente le nombre de livre
			old=$(echo "$decade_book" | grep "^$decade" |sed -E "s/.*: ([0-9]+) .*/\1/")
			new=$((old + 1))
			decade_book=$(echo "$decade_book" | sed -E "s/($decade : )$old livre(s)?/\1$new livres/")
		fi
	done < "$1"

	# sort -n permet de trier dans l'ordre numérique et non lexicographique
	echo "$decade_book" | sort -n
}

#REMIND ME: Les stats restantes à mettre sont nb_livre/genre
export_html() {
	html_file="<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Statistiques de la bibliothèque</title>
	<link rel=\"stylesheet\" href=\"style.css\">
</head>
<body>
	<h1>Statistiques de la bibliothèque : \"$1\"</h1>
	
	<h2>Nombre de livre dans la bibliothèque</h2>
	<p> Dans la bibliothèque, il y a <strong>$(nb_book "$1")</strong> livre(s).</p>

	<h2>Top 5 des auteurs de la bibliothèque</h2>
	<p> Voici le tableau des auteurs les plus présents de la bibliothèque :</p>
	<table>
		<thead>
			<tr>
				<th>Place</th>
				<th>Auteur</th>
				<th>Nombre de livres</th>
			</tr>
		</thead>
		<tbody>"

	top_author=$(top_five "$1")
	while read -r line; do
		rank=$(echo "$line" | sed -E "s/^([1-5]).*/\1/")
		author=$(echo "$line" | sed -E "s/^[1-5]\. (.*)\|.*/\1/")
		nb_book=$(echo "$line" | sed -E "s/.*\|([0-9]+)/\1/")
		
		html_file="$html_file
			<tr>
				<td>$rank</td>
				<td>$author</td>
				<td>$nb_book</td>
			</tr>"
	done <<< "$top_author"

	html_file="$html_file
		</tbody>
	</table>
	
	<h2>Nombre de livre par décennies</h2>
	<p> Voici le tableau du nombre de livres sorti par décennie :
	<table>
		<thead>
			<tr>
				<th>Décennie</th>
				<th>Nombre de livres sortis</th>
			</tr>
		</thead>
		<tbody>"

	book_by_decades=$(stats_books_decades "$1")
	while read -r line; do
		decade=$(echo "$line" | sed -E "s/^([0-9]+) .*/\1/")
		nb_book=$(echo "$line" | sed -E "s/.*: ([0-9]+).*/\1/")
		html_file="$html_file
			<tr>
				<td>$decade</td>
				<td>$nb_book</td>
			</tr>"
	done <<< "$book_by_decades"

	html_file="$html_file
		</tbody>
	</table>
	<h2>Répartition des livres par genre</h2>
	<p>Voici le tableau de la répartition des livres par genre
	<table>
		<thead>
			<tr>
				<th>Genre</th>
				<th>Nombre de livres</th>
			</tr>
		</thead>
		<tbody>"

	gender_stat=$(stats_gender "$1" 2>/dev/null | sort) #2>/dev/null permet de récupérer uniquement la sortie standard
	while read -r line; do
		gender=$(echo "$line" | sed -E 's/^([^ ]+( [^ ]+)?) *\(.*/\1/')
		nb_book=$(echo "$line" | grep -Eo "#+")
		html_file="$html_file
			<tr>
				<td>$gender</td>
				<td>$nb_book</td>
			</tr>"
	done <<< "$gender_stat"

	html_file="$html_file
		</tbody>
	</table>
</body>
</html>"
	echo "$html_file" > "$2"
	echo "Les statistiques on été exportées dans le fichier \"$2\"."
}

#Export les statististiques de la bibliothèque principal en pdf, l'export requiert 2 outils supplémentaires :
# pandoc (v3.2.1) & wkhtmltopdf (v0.12.6.1)
export_pdf() {
	export_html "$1" "stats.html" >/dev/null

	#La condition ci dessus vérifie le code de sortie de la commande, si ça fonctionne cela signifie que les outils
	#nécessaires sont disponibles
	if pandoc -v>/dev/null 2>&1 && wkhtmltopdf -V>/dev/null 2>&1; then #"Jette" les stdin & stderr
		echo "Vous avez pandoc et wkhtmltopdf. L'export en pdf est possible."
		pandoc stats.html -o "$2" --pdf-engine=wkhtmltopdf>/dev/null 2>&1
		rm "stats.html"
		echo "L'export a été réalisé sous le nom \"$2\""
	else
		echo "Vous n'avez pas pandoc ou wkhtmltopdf. L'export en pdf n'est pas possible..."
		echo "Veuillez installer ces outils afin de pouvoir faire l'export en pdf."
	fi
}

#Permet de choisir le format de l'export et de lancer la fonction attribuer
export_data() { #export
	echo "Vous avez choisi d'exporter vos données. À quel format les souhaitez vous ?
	1. PDF
	2. HTML"
	while true; do
		read -rp "Votre choix (1, 2) : " file_type	
		case "$file_type" in
			1)
				echo "Vous avez choisi le format PDF."
				file_name=$(ask_file_name)".pdf"
				echo "Le fichier sera $file_name"
				export_pdf "$1" "$file_name"
				break
				;;
			2)
				file_name=$(ask_file_name)".html"
				echo "Le fichier sera $file_name"
				export_html "$1" "$file_name"
				break
				;;
			*)
				echo "Le choix n'est pas valide."
				;;		
		esac
	done
}

#Demande le nom du fichier pour l'export
ask_file_name() {
	read -rp "Quel nom de fichier souhaitez vous donner (ne pas préciser l'extension) ? " file_name
	while ! [[ "$file_name" =~ ^[A-Za-z0-9._-]+$ ]]; do
		echo "Le nom de fichier n'est pas valide." >&2
		read -rp "Quel nom de fichier souhaitez vous donner (ne pas préciser l'extension) ? " file_name
	done
	echo "$file_name"
}

########################################## Emprunts ##########################################
#fonction pour emprunté un livre
emprunter_livre () { #emprunter_livre
	book=$(exist_book "$1") #lance la recherche d'id
	dispo=$(echo "$book" | cut -d"|" -f6) #recupere la dispo
	if [ "$dispo" == "emprunté" ]
	then
		echo "Livre déja emprunté !"
		return 1
	fi
	read -rp "Voulez vous emprunter le livre (Y/n) : $book " answer
	[ "$answer" == "n" ] && return 1
	id=$(echo "$book" | cut -d"|" -f1) #recupere l'id du livre
	sed -i "s/^\($id|[^|]*|[^|]*|[^|]*|[^|]*|\).*/\1emprunté/" "$1" #change disponible par emprunté
	date_actuel=$(date +"%Y-%m-%d") #date actuelle
	date_rendu=$(date -d "+2 months" +"%Y-%m-%d") #date_actuelle + 2mois
	read -rp "Votre nom : " nom
	emprunt="$id|$nom|$date_actuel|$date_rendu"
	echo "$emprunt" >> "$2"
	make_backup
}

#fonction pour retourner un livre
return_livre () { #retourner_livre
	book=$(exist_book "$1") # lance la recherche d'id
	dispo=$(echo "$book" | cut -d"|" -f6) #recupere la dispo
	id=$(echo "$book" | cut -d"|" -f1) #recupere l'id 
	if [ "$dispo" != "disponible" ] #si le livre est dispo
	then
		read -rp "Voulez vous rendre le livre (Y/n) : $book " answer #demande de confirmation du rendu
		[ "$answer" == "n" ] && return 1

		sed -i "s/^\($id|[^|]*|[^|]*|[^|]*|[^|]*|\).*/\1disponible/" "$1" #remettre le livre en disponible
		echo $book
		echo "Livre rendu !"
		make_backup
		return 1
	else
		echo "Aucun livre emprunté pour cet ID" >&2
	fi	
}

#afficher les liste emprunté 
list_livre_emprunte() { #lister_livre_emprunter
	local file="$1" #récupère le fichier data
	check=0 #check si il y a eu moins un livre

	#boucle pour écrire tous les livre au status "emprunté"
	while IFS="|" read -r id title author year genre status; do
        if [[ "${status,,}" == "emprunté" ]]; then
			check=1
            printf "%-3s | %-30s | %-20s | %-4s | %-15s | %-12s\n" \
            "$id" "$title" "$author" "$year" "$genre" "$status"
        fi
    done < "$file"

	#si aucun livre n'est emprunté
	if [[ $check == 0 ]]; then 
		echo "aucun livre emprunté"
	fi

}

#Liste les livres en retards
retard_emprunt () { #retard
	retard="" # livre en retard
	liste_emprunte="" # livre emprunte
	nb_ligne=$(($(cat "$1" | wc -l)-1)) # nb de ligne dans data
	# Recupere les liste emprunté
	for i in $(seq 1 "$nb_ligne")
	do
		ligne=$(cat "$1" | tail -"$i" | head -1)
		dispo=$(echo "$ligne" | cut -d"|" -f6)
		[ "$dispo" == "emprunté" ] && [ "$liste_emprunte" != "" ] && liste_emprunte="$liste_emprunte"$'\n'"$ligne"
		[ "$dispo" == "emprunté" ] && [ "$liste_emprunte" == "" ] && liste_emprunte="$ligne"
	done
	nb=$(($(cat "$2" | wc -l)-1)) # nb ligne dans emprunts
	today=$(date +%s) # int date aujourdhui
	# Pour chaque ligne dans emprunts
	for i in $(seq 1 "$nb")
	do
		ligne=$(cat "$2" | tail -"$i" | head -1) # ligne emprunt
		id=$(echo "$ligne" | cut -d"|" -f1) # id de la ligne
		nb_ligne=$(echo "$liste_emprunte" | wc -l) # nb de ligne dans liste_emprunte
		# Pour chaque ligne dans liste_emprunte
		for i in $(seq 1 "$nb_ligne")
		do
			ligne2=$(echo "$liste_emprunte" | tail -"$i" | head -1) # ligne liste_emprunte
			id2=$(echo "$ligne2" | cut -d"|" -f1) # id de la ligne de liste_emprunte
			if [ "$id" == "$id2" ] # si les deux id correspond
			then
				date_prevu=$(echo "$ligne" | cut -d"|" -f4) # date prevu de rendu
				date_prevu_int=$(date -d "$date_prevu" +%s) # date prevu de rendu -> int
				if [ "$today" -gt "$date_prevu_int" ] # si la date de aujourd'hui est plus grand que la date de rendu prevu
				then
					retard="$retard"$'\n'"$ligne2" # on ajoute a retard
				fi	
				liste_emprunte=$(echo "$liste_emprunte" | sed "/^${id}|/d") # on enleve le livre de liste_emprunte
				break
			fi
		done
	done
	[ "$retard" == "" ] && echo "Aucun retard !" && return 1
	echo "$retard"
}

emprunts_history(){ #historique
	local file_emprunts="$1" #récupère le fichier d'emprunts

	#boucle d'affichage de tous les emprunts dans emprunts.txt
	while IFS="|" read -r id nom date_emprunt date_rendu; do
        printf "%-3s | %-30s | %-12s | %-12s \n" \
        "$id" "$nom" "$date_emprunt" "$date_rendu"
    done < "$file_emprunts"
}
