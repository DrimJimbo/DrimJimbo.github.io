
# Système de Gestion de Bibliothèque Personnelle

## Description

Ce projet implémente un système de gestion de bibliothèque personnelle en ligne de commande, développé en Bash. Il permet la manipulation de données structurées stockées dans des fichiers texte plats (sans base de données), avec un menu interactif pour gérer les livres, les recherches, les statistiques, et les emprunts. Les fonctionnalités incluent l'ajout, la modification, la suppression de livres, des recherches et filtres avancés, des rapports statistiques, ainsi que la gestion des emprunts avec alertes pour retards. Le système assure une sauvegarde automatique après chaque modification et un backup quotidien.

Le projet respecte les contraintes techniques spécifiées : utilisation exclusive de fichiers texte (livres.txt pour les livres, emprunts.txt pour les emprunts), validation des saisies utilisateur, et navigation interactive via menus.

## Prérequis

- Environnement : Unix-like (Linux, macOS) avec Bash (version 4+ recommandée).
- Outils optionnels pour l'export PDF :
  - Pandoc (version 3.2.1 ou supérieure).
  - wkhtmltopdf (version 0.12.6.1 ou supérieure).
- Aucun autre dépendance externe n'est requise pour les fonctionnalités de base.

## Installation

1. Clonez ou téléchargez les fichiers du projet dans un répertoire dédié.
2. Assurez-vous que les scripts sont exécutables :

   ```bash
   chmod +x bibliotheque.sh
   ```

3. Créez un répertoire `backups` pour stocker les sauvegardes :

   ```bash
   mkdir backups
   ```

4. Préparez les fichiers de données (voir la section "Jeux de données de test" ci-dessous).

## Utilisation

Lancez le script principal avec la commande suivante :

```bash
./bibliotheque.sh
```

- Le script demandera le chemin vers le fichier de données des livres (ex. : `livres.txt`).
- Il demandera ensuite le chemin vers le fichier des emprunts (ex. : `emprunts.txt`).
- Une interface menu interactive s'affichera, avec des options numérotées ou nommées (ex. : `1` ou `gestion_des_livres`).
- Commandes spéciales disponibles dans tous les menus :
  - `clear` : Efface l'écran et réaffiche le menu.
  - `help` : Affiche l'aide.
  - `exit` : Quitte le programme.
  - `retour` : Retourne au menu précédent.

Exemple de navigation :

- Entrez `1` pour accéder à la gestion des livres.
- Utilisez les flèches gauche/droite pour paginer les listes de livres.

Le système effectue une sauvegarde automatique après chaque modification et un backup quotidien dans le répertoire `backups` (fichiers nommés `backup_DD_MM_YYYY`).

## Fonctionnalités

### Gestion des livres

- **Ajouter un livre** : Génération automatique d'ID, saisie validée du titre, auteur, année, genre. Statut par défaut : "Disponible".
- **Modifier un livre** : Recherche par ID, mise à jour sélective des champs (titre, auteur, année, genre).
- **Supprimer un livre** : Recherche par ID, suppression confirmée, avec mise à jour des emprunts associés.
- **Lister tous les livres** : Affichage paginé (20 lignes par page), navigation avec flèches gauche/droite ou 'q' pour quitter.

### Recherche et filtres

- **Rechercher par titre** : Recherche partielle insensible à la casse.
- **Rechercher par auteur** : Recherche partielle insensible à la casse.
- **Filtrer par genre** : Liste des genres disponibles, puis filtrage exact.
- **Filtrer par année** : Plage de dates (année min/max).
- **Recherche avancée** : Combinaison de critères (titre, auteur, genre, plage d'années). Champs vides ignorés.

### Statistiques et rapports

- **Nombre total de livres** : Compte simple des entrées.
- **Répartition par genre** : Graphique ASCII avec barres (#) et comptage.
- **Top 5 auteurs** : Auteurs avec le plus de livres (en cas d'égalité, priorisation par ordre d'apparition inverse).
- **Livres par décennie** : Comptage trié par décennie (ex. : 1890, 1900).
- **Export des résultats** : En HTML ou PDF (via pandoc et wkhtmltopdf). Inclut toutes les statistiques dans un tableau structuré.

### Emprunts

- **Emprunter un livre** : Vérification de disponibilité, saisie du nom de l'emprunteur, dates d'emprunt (actuelle) et retour prévu (+2 mois). Mise à jour du statut.
- **Retourner un livre** : Recherche par ID, confirmation, remise en "Disponible".
- **Lister les livres empruntés** : Affichage des livres au statut "emprunté".
- **Alertes pour retards** : Liste des livres dont la date de retour prévue est dépassée (comparaison avec date actuelle).
- **Historique des emprunts** : Affichage complet du fichier emprunts.txt.

### Contraintes techniques implémentées

- Fichiers texte uniquement : livres.txt (format : ID|Titre|Auteur|Année|Genre|Statut) et emprunts.txt (format : ID_Livre|Emprunteur|Date_Emprunt|Date_Retour_Prévue).
- Menu interactif avec navigation.
- Validation des saisies : Champs non vides, années valides (numériques, <= année actuelle), genres prédéfinis ou personnalisés.
- Sauvegarde automatique : Appel à `make_backup` après modifications.
- Système de backup quotidien : Dossier par date, écrasé si existant.

## Contributeurs

- **Étudiant 1** : Billaud Ryan (Numéro d'étudiant : [22204241]).

- **Étudiant 2** : Cavenaile Aymerik (Numéro d'étudiant : [22205062]).  

- **Étudiant 3** : Desmet Romain (Numéro d'étudiant : [22300656]).  

## Contributions de chacun

- **Billaud Ryan (Numéro d'étudiant : 22204241)** :  
  Responsable de la création des scripts principaux et de la bibliothèque de fonctions (en collaboration), de la préparation des fichiers et jeux de données de test (en collaboration), de l'ajout de livres avec génération automatique d'ID et vérification de doublons, du backup automatique après modifications, de la répartition par genre avec graphique ASCII, des livres par décennie, des exports en HTML et PDF, de la fonction principale d'export avec choix de format, du système de backup quotidien, de la validation des saisies utilisateur (en collaboration), de la sauvegarde automatique (en collaboration), de la séparation des fonctions réutilisables, et des tests pour les exports.

- **Cavenaile Aymerik (Numéro d'étudiant : 22205062)** :  
  Responsable de la création des scripts principaux et de la bibliothèque de fonctions (en collaboration), de la préparation des fichiers et jeux de données de test (en collaboration), du menu principal, des sous-menus pour la gestion des livres, la recherche et filtres, les statistiques et rapports, les emprunts, et du menu d'aide avec option -h, de la modification et suppression de livres, du nombre total de livres, du top 5 auteurs, de l'emprunt de livres avec vérification de disponibilité, des alertes pour retards, de la validation des saisies utilisateur (en collaboration), et de la sauvegarde automatique (en collaboration).

- **Desmet Romain (Numéro d'étudiant : [22300656])** :  
  Responsable de la création des scripts principaux et de la bibliothèque de fonctions (en collaboration), de la préparation des fichiers et jeux de données de test (en collaboration), de la liste des livres avec pagination, des recherches par titre (partielle et insensible à la casse), par auteur, du filtrage par genre et par année (plage de dates), de la recherche avancée combinée, du retour de livres avec mise à jour du statut, de la liste des livres empruntés, de l'historique des emprunts, de la validation des saisies utilisateur (en collaboration), et de la sauvegarde automatique (en collaboration).

## Jeux de données de test

- **livres.txt** (exemple de contenu) :

  ```txt
  ID|Titre|Auteur|Année|Genre|Statut
  1|1984|George Orwell|1949|Dystopie|Disponible
  2|Le Petit Prince|Antoine de Saint-Exupéry|1943|Conte|emprunté
  3|Harry Potter à l'école des sorciers|J.K. Rowling|1997|Roman|Disponible
  4|Le Seigneur des Anneaux|J.R.R. Tolkien|1954|Roman|Disponible
  5|To Kill a Mockingbird|Harper Lee|1960|Roman|Disponible
  ```

- **emprunts.txt** (exemple de contenu) :

  ```txt
  ID_Livre|Emprunteur|Date_Emprunt|Date_Retour_Prévue
  2|Jean Dupont|2025-10-01|2025-12-01
  ```

Ces fichiers peuvent être étendus pour tester les fonctionnalités complètes. Assurez-vous que les extensions sont .txt ou .csv (le script vérifie cela).
