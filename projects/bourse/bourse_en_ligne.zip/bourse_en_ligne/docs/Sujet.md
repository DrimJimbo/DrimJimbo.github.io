# Sujet  v1.0
## Présentation du sujet

L'objectif est de créer un outil de bourse en ligne virtuel. Les fonctionnalités attendues sont les suivantes :

  - Gestion des différents utilisateurs (authentification, état-civil, porte-monnaie virtuel, photo/avatar, etc)
  - Gestion du portefeuille (achat/vente virtuels)
  - Tableau de bord paramétrable (différents graphiques sur la valorisation du portefeuille, des actions préférées, etc.)

Tous les graphiques doivent être paramétrables (dates début/fin, moyenne lissée ou non, pas de temps, etc.). L'ergonomie et les fonctionnalités du site seront une part importante de la note.

## Contraintes techniques

L'application 4 tiers devra utiliser les technologies suivantes :

  - Côté client JavaScript natif ([Bootstrap](http://getbootstrap.com/), et [jquery](https://jquery.com/) autorisés) + HTML5 + CSS. Pour les graphiques, utilisez une bibliothèque de votre choix ([Chart.js](https://www.chartjs.org/), [D3.js](https://d3js.org/),...).
  - La partie serveur se fera en PHP 8 (sans framework) et basée sur des services web.
  - La base de donnée sera SQLite3 
  - Pour les différents cours des actions, on utilisera l'API [Alpha Vantage](https://www.alphavantage.co/documentation/) depuis le serveur en php (pas directement depuis le client en js). Vous devrez vous créer une [API key](https://www.alphavantage.co/support/#api-key).

Toute utilisation d'une bibliothèque/API annexe devra être validée par l'enseignant.

Les projets seront stockés sur [gitlab](https://gitlab.univ-artois.fr/)  et partagés avec moi (johan.koitka@univ-artois.fr)

D'un point de vue sécurité, toute injection de code trop aisée ou récupération de la base sera très sévèrement sanctionnée.

Les projets doivent pouvoir tourner sur les machines des salles TP.

## Infos pratiques

projet à effectuer en binôme (pas de trinôme)
Date de rendu du projet : 15 mars. la note sera individuelle, des modifications seront demandées lors de la dernière séance de TP pour vérifier que vous maitrisez le code.
Un mini rapport technique devra être constitué reprenant :
  - les choix techniques
  - l'architecture choisie
  - un schéma de la base de données

## Changelog

  v1.0 – version initiale
