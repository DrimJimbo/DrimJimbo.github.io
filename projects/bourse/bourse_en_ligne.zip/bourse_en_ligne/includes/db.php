<?php
$pdo = connectDB();
initDB();


function connectDB(){
  try {
    $chemin_bdd = __DIR__ . '/../bdd/db.sqlite';

    // Connexion PDO
    $pdo = new PDO('sqlite:' . $chemin_bdd);

    // Activation des erreurs pour le développement
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $pdo;
  } catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
  }
}

function initDB(){
  global $pdo;

  $createUserTable = "CREATE TABLE IF NOT EXISTS users (
      id_user INTEGER PRIMARY KEY AUTOINCREMENT,
      username VARCHAR(50) UNIQUE NOT NULL,
      email VARCHAR(50) UNIQUE NOT NULL,
      password VARCHAR(255) NOT NULL,
      name VARCHAR(50) NOT NULL,
      surname VARCHAR(50) NOT NULL,
      marital_status VARCHAR(50) NOT NULL,
      gender VARCHAR(50) DEFAULT 'Prefer not to say',
      birth_date DATE NOT NULL,
      value_wallet REAL DEFAULT 0, -- indique la valeur du porte monnaie en euro
      path_avatar VARCHAR(255) DEFAULT '/images/default_avatar.jpg'
    );";

  $createWalletTable = "CREATE TABLE IF NOT EXISTS wallet (
    id_wall INTEGER PRIMARY KEY AUTOINCREMENT,
    id_user INTEGER,
    name_action VARCHAR(50),
    symbol_action VARCHAR(50),
    prix_achat FLOAT,
    quantity INTEGER,
    -- Définition de la clé étrangère ici :
    FOREIGN KEY (id_user) REFERENCES users(id_user) 
        ON DELETE CASCADE
    );";

  try {
    $pdo->exec($createUserTable);
    $pdo->exec($createWalletTable);
  } catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
  }
  
}
?>