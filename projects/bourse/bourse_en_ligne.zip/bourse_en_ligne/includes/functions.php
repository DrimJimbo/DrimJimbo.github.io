<?php
require_once "db.php";
$api_aym = "KN58G7DK4WU5L6O3";
function addUser($username, $email, $password, $name, $surname, $marital_status, $gender, $birth_date){
  global$pdo;
  
  $request = "INSERT INTO users (username, email, password, name, surname, marital_status, gender, birth_date)
  VALUES (:username, :email, :password, :name, :surname, :marital_status, :gender, :birth_date)";

  $request = $pdo->prepare($request);

  try {
    $request->execute([
      ':username' =>  $username,
      ':email'  =>  $email,
      ':password' =>  password_hash($password, PASSWORD_DEFAULT),
      ':name' =>  $name,
      ':surname'  =>  $surname,
      ':marital_status' =>  $marital_status,
      ':gender' =>  $gender,
      ':birth_date' =>  $birth_date,
    ]);
  } catch (PDOException $e) {
    die("Erreur SQL : " . $e->getMessage());
  }
}

function connectUser($username, $password){
  global $pdo;
  $request = "SELECT * FROM users WHERE username = :username";
  $request = $pdo->prepare($request);
  try {
    $request->execute([
      ":username"=> $username
    ]);

    if (($user = $request->fetch(PDO::FETCH_ASSOC)) != false) {
      if (password_verify($password, $user['password'])){
        return 0; //Tout s'est bien passé
      } else {
        return 2; //Le mot de passe est incorrect
      }
    } else {
      return 1; //Cela signifie que l'utilisateur, n'a pas été trouvé
    }
  } catch (PDOException $e) {
    die("". $e->getMessage());
  }
}

function estMajeur($birthDate) {
    $now = new DateTime();
    $birth = new DateTime($birthDate);
    
    // On calcule la différence entre les deux dates
    $diff = $now->diff($birth);
    
    // On retourne vrai si le nombre d'années est >= 18
    return $diff->y >= 18;
}

function valueExist($table, $column, $value) {
  global $pdo;  
  
  $request = "SELECT $column FROM $table WHERE $column = :value";

  $re = $pdo->prepare($request);
  try {
    $re->execute([":value"=> $value]);
    return $re->fetch() != false;
  } catch (PDOException $e) {
    $e->getMessage();
  }
}

function getPrice($symbol){
    global $api_aym;
    $url = "https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=$symbol&apikey=$api_aym";

    // On récupère le contenu JSON
    $json = @file_get_contents($url);
    if ($json === false){
      echo "Erreur réseau";
      return 0;
    }
    $data = json_decode($json, true);

    // Alpha Vantage renvoie les données sous la clé "Global Quote"
    // Le prix est dans "05. price"
    if (isset($data['Global Quote']['05. price'])) {
        return (float)$data['Global Quote']['05. price'];
    }

    return 0; // Symbole non trouvé ou limite d'API atteinte
}

function vendre($id,$qte,$prix_actuel){
  global $pdo;
    $query = "SELECT * FROM wallet WHERE id_wall = :id";
    $request = $pdo->prepare($query);
    try {
      $request->execute([
        ":id" => $id
      ]);
      $res = $request->fetch();
      $new_qte = $res['quantity'] - $qte;
      if($new_qte == 0){
        $query = "DELETE FROM wallet WHERE id_wall = :id";
        $request = $pdo->prepare($query);
        $request->execute([
          ":id" => $id,
        ]);
      }else{
        $query = "UPDATE wallet SET quantity = :qte WHERE id_wall = :id";
        $request = $pdo->prepare($query);
        $request->execute([
          ":qte" => $new_qte,
          "id" => $id,
        ]);
      }
      $query = "UPDATE users SET value_wallet = value_wallet + :solde WHERE username = :id";
      $request = $pdo->prepare($query);
      $request->execute([
        ":solde" => ($qte * $prix_actuel),
        ":id" => $_SESSION['user'],
      ]);

    }catch (PDOException $e){
      die("Probléme de vente : ". $e->getMessage());
    }
}

function changeUser($username,$pic,$name,$surname,$mail,$date,$gender,$marital){
  global $pdo;
  if($pic == null){
    $query = "UPDATE users SET email = :email, name = :name, surname = :surname, marital_status = :marital_status, gender = :gender, birth_date = :birth_date WHERE username = :user";
    $request = $pdo->prepare($query);
    try {
      $request->execute([
        ":email" => $mail,
        ":name" => $name,
        ":surname" => $surname,
        ":marital_status" => $marital,
        ":gender" => $gender,
        ":birth_date" => $date,
        ":user" => $username,
      ]);
    }catch (PDOException $e){
      die("Erreur changement infos ".$e->getMessage());
    }
  }
  else{
    $query = "UPDATE users SET email = :email, name = :name, surname = :surname, marital_status = :marital_status, gender = :gender, birth_date = :birth_date, path_avatar = :path_avatar WHERE username = :user";
    $request = $pdo->prepare($query);
    try {
      $request->execute([
        ":email" => $mail,
        ":name" => $name,
        ":surname" => $surname,
        ":marital_status" => $marital,
        ":gender" => $gender,
        ":birth_date" => $date,
        ":path_avatar" => $pic,
        ":user" => $username,
      ]);
    }catch (PDOException $e){
      die("Erreur changement infos ".$e->getMessage());
    }
  }
}

function downloadPic($pic,$username){
  $dir = "images/";
  $name = $pic['name'];
  $filetemp = $pic['tmp_name'];
  $extension = strtolower(pathinfo($name,PATHINFO_EXTENSION));
  $new_name = $username.".".$extension;
  $dest = $dir.$new_name;
  move_uploaded_file($filetemp,$dest);
  return $dest;
}

function deposer($username,$amout,$solde){
  global $pdo;
  $newsolde = round($solde+floatval($amout),2);
  $query = "UPDATE users SET value_wallet = :solde WHERE username = :username";
  $request = $pdo->prepare($query);
  try{
    $request->execute([
      ":solde" => $newsolde,
      ":username" => $username
    ]);
  }catch (PDOException $e){
    die("Erreur lors que l'ajout de fond : ".$e->getMessage());
  }
}

function retirer($username,$amout,$solde){
  global $pdo;
  $newsolde = round($solde - floatval($amout),2);
  $query = "UPDATE users SET value_wallet = :solde WHERE username = :username";
  $request = $pdo->prepare($query);
  try{
    $request->execute([
      ":solde" => $newsolde,
      ":username" => $username
    ]);
  }catch (PDOException $e){
    die("Erreur lors que l'ajout de fond : ".$e->getMessage());
  }
}

?>
