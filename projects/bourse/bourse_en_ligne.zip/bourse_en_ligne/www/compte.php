<?php
    include_once "../includes/functions.php";
    session_start();
    global $pdo;
    if(!isset($_SESSION['user'])){
        header('Location: index.php');
        exit();
    }
    $query = "SELECT * FROM users WHERE username = :user";
    $request = $pdo->prepare($query);
    try{
        $request->execute([
            ":user" => $_SESSION['user'],
        ]);
        $res = $request->fetch();
    }catch (PDOException $e){
        die("Erreur Recup user : ".e->getMessage());
    }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <title>Vendre</title>
</head>
<body>
    <div class="container-fluid">
    <div class="row">
        <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse min-vh-100">
            <div class="position-sticky pt-3">
                <h5 class="text-white px-3 mb-4">StockManager</h5>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link text-white active" href="wallet.php">
                             Wallet
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="marche.php">
                            Marché
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="compte.php">
                             Compte
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="retrait.php">
                             Retrait/Dêpot
                        </a>
                    </li>
                    <li class="nav-item">
                        <form  method="post" class="nav-link text-danger mt-5">
                            <input type="submit" value="Déconnexion" name="sub" class="btn btn-outline-danger btn-sm d-flex align-items-center gap-2"/>
                        </form>
                    </li>
                </ul>
            </div>
        </nav>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="card shadow-sm text-center">
                    <div class="card-body p-4">
                        <div class="profile-avatar-container mb-3">
                            <img src="<?= $res['path_avatar'] ?>" 
                                class="rounded-circle shadow w-100" 
                                alt="Photo de profil"
                                style="max-width: 150px; min-width: 50px; aspect-ratio: 1/1; object-fit: cover;">
                        </div>
                        <h4 class="fw-bold mb-1"><?= htmlspecialchars($res['name'] . ' ' . $res['surname']) ?></h4>
                        <p class="text-muted small mb-3">@<?= htmlspecialchars($res['username']) ?></p>
                        
                        <div class="wallet-stat p-3 bg-light rounded-3">
                            <p class="text-muted small mb-1">Solde disponible</p>
                            <h3 class="text-primary mb-0"><?= number_format($res['value_wallet'], 2, ',', ' ') ?> €</h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="card shadow-sm">
                    <div class="card-header bg-white py-3">
                        <h5 class="mb-0">Détails du Profil</h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label text-muted small fw-bold">Prénom</label>
                                <p class="form-control-plaintext border-bottom"><?= htmlspecialchars($res['surname']) ?></p>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label text-muted small fw-bold">Nom</label>
                                <p class="form-control-plaintext border-bottom"><?= htmlspecialchars($res['name']) ?></p>
                            </div>
                            <div class="col-md-12">
                                <label class="form-label text-muted small fw-bold">Adresse Email</label>
                                <p class="form-control-plaintext border-bottom"><?= htmlspecialchars($res['email']) ?></p>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label text-muted small fw-bold">Genre</label>
                                <p class="form-control-plaintext border-bottom"><?= htmlspecialchars($res['gender'] ?? 'Non précisé') ?></p>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label text-muted small fw-bold">Date de naissance</label>
                                <p class="form-control-plaintext border-bottom"><?= htmlspecialchars($res['birth_date'] ?? 'N/A') ?></p>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label text-muted small fw-bold">Statut Marital</label>
                                <p class="form-control-plaintext border-bottom"><?= htmlspecialchars($res['marital_status'] ?? 'N/A') ?></p>
                            </div>
                        </div>
                        
                        <div class="mt-4 pt-3 border-top">
                            <form method='post'>
                                <a class="btn btn-primary px-4" href="modifinfo.php">Modifier les informations</a>
                                <a class="btn btn-primary px-4" href="modifpassword.php">Modifier le mot de passe</a>
                                <input type='submit' class="btn btn-danger px-4 " id="btn_suppr" value='Supprimer le compte' name='suppr'/>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
</div>
</div>
<?php
    if(isset($_POST['suppr'])){
        $count = 0;
        $query = "SELECT COUNT(*) FROM wallet JOIN users ON wallet.id_user = users.id_user WHERE username = :user";
        $request = $pdo->prepare($query);
        try{
            $request->execute([
                ":user" => $_SESSION['user'],
            ]);
            $r = $request->fetch();
        }catch (PDOException $e){
            die("Erreur de récupération : ".$e->getMessage());
        }
        if($res['value_wallet'] != 0 || $r['COUNT(*)'] != 0){
            echo "<script>alert('Veuillez vendre toutes vos actions et vider votre solde avant de supprimer votre compte !')</script>";
        }
        else {
            echo "<script>
                    let btn = document.getElementById('btn_suppr');
                    btn.value = 'Confirmer la suppression';
                    btn.name = 'confirmer';
                </script>";
        }
    }
    if(isset($_POST['confirmer'])){
        $query="DELETE FROM users WHERE username = :user";
        $request = $pdo->prepare($query);
        try{
            $request->execute([
                ":user" => $_SESSION['user'],
            ]);
            echo "<script>alert('Compte supprimer !')</script>";
            session_destroy();
            header("Location: index.php");
        }catch (PDOException $e){
            die("Erreur de récupération : ".$e->getMessage());
        }
    }
?>
</body>
</html>
        