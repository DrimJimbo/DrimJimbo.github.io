<?php 
  require_once "../includes/functions.php";
  session_start();
  if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $password = $_POST["passwordInput"];
    $username = $_POST["usernameInput"];

    $codeReturned = connectUser($username, $password);

    switch ($codeReturned) {
      case 1:
      case 2:
        header("Location: " . $_SERVER['PHP_SELF'] .'?code_erreur='.$codeReturned);
        exit();
      default:
        $_SESSION['user'] = $username;
        header("Location: wallet.php");
        exit();
    }
  }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="./css/index.css" rel="stylesheet"/>
  <title>Connexion</title>
</head>
<body>
  <main>
    <section id="connectContent">
      <h2>Se connecter</h2>
      <form action="" method="post">
        <fieldset>
          <div id="username">
            <label for="usernameInput">Nom d'utilisateur : </label></br>
            <input type="text" name="usernameInput" id="usernameInput" required>
          </div>
          <div id="password">
            <label for="passwordInput">Mot de passe : </label></br>
            <input type="password" name="passwordInput" id="passwordInput" required>
          </div>
          <div id="submit">
            <a href="new_user.php">Créer un compte</a>
            <input type="submit" value="Se connecter">
          </div>
        </fieldset>
      </form>
    </section>
  </main>
</body>
</html>