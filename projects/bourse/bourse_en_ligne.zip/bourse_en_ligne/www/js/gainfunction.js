let quantity = document.getElementById("qte");
let price = document.getElementById("price");
g();
quantity.addEventListener("input", g);
function g() {
    let actuel = parseFloat(quantity.value);
    let gain = parseFloat(price.textContent) * actuel;
    let ch = document.getElementById("gain");
    ch.textContent = "gain : " + parseFloat(gain).toFixed(2) + "€";
}
