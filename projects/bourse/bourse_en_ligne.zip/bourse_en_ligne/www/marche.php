<?php
require_once "../includes/functions.php";
session_start();
global $pdo;

if (isset($_GET['action']) && $_GET['action'] === 'get_chart_data') {
    header('Content-Type: application/json');
    $symbol = $_GET['symbol'] ?? 'AAPL';
    $range = $_GET['range'] ?? 'month'; // 'month' ou 'year'
    
    global $api_aym;
    $url = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={$symbol}&apikey={$api_aym}";
    
    $json = @file_get_contents($url);
    if ($json === false) {
        echo json_encode(['error' => 'Erreur réseau avec l\'API']);
        exit;
    }
    
    $data = json_decode($json, true);
    if (!isset($data['Time Series (Daily)'])) {
        echo json_encode(['error' => 'Symbole introuvable ou limite d\'API atteinte']);
        exit;
    }

    $timeSeries = $data['Time Series (Daily)'];
    $labels = [];
    $prices = [];
    $limit = ($range === 'month') ? 30 : 365; // Limiter les points selon la période choisie
    
    $count = 0;
    foreach ($timeSeries as $date => $values) {
        if ($count >= $limit) break;
        $labels[] = $date;
        $prices[] = (float)$values['4. close']; // On prend le prix de clôture
        $count++;
    }
    
    // Alpha Vantage donne les dates de la plus récente à la plus ancienne, on inverse pour le graphique
    echo json_encode([
        'labels' => array_reverse($labels),
        'prices' => array_reverse($prices)
    ]);
    exit;
}

// Redirection si non connecté
if(!isset($_SESSION['user'])){
    header("Location: index.php");
    exit();
}

$message = "";
$searched_price = null;
$searched_symbol = $_GET['symbol'] ?? "";

// Gérer la recherche de l'action pour le prix actuel
if(!empty($searched_symbol)){
    $searched_symbol = strtoupper(trim($searched_symbol));
    $searched_price = getPrice($searched_symbol); // Utilise ta fonction existante (GLOBAL_QUOTE)
    if($searched_price == 0){
        $message = "<div class='alert alert-danger'>Symbole introuvable ou limite d'API atteinte.</div>";
    }
}

// Gérer l'achat de l'action (en FLOAT)
if(isset($_POST['acheter'])){
    $symbol = strtoupper(trim($_POST['symbol']));
    $qte = (float)$_POST['qte']; // Cast en float pour les fractions d'actions
    $prix_actuel = (float)$_POST['prix'];
    $total_cost = $qte * $prix_actuel;
    $username = $_SESSION['user'];

    $req_user = $pdo->prepare("SELECT id_user, value_wallet FROM users WHERE username = :user");
    $req_user->execute([':user' => $username]);
    $user_data = $req_user->fetch();

    if($user_data && $user_data['value_wallet'] >= $total_cost && $qte > 0){
        $new_solde = $user_data['value_wallet'] - $total_cost;
        
        // Sécurité avec requêtes préparées
        $req_update = $pdo->prepare("UPDATE users SET value_wallet = :solde WHERE id_user = :id");
        $req_update->execute([':solde' => $new_solde, ':id' => $user_data['id_user']]);

        $req_check = $pdo->prepare("SELECT id_wall, quantity FROM wallet WHERE id_user = :id_user AND symbol_action = :symbol");
        $req_check->execute([':id_user' => $user_data['id_user'], ':symbol' => $symbol]);
        $existing_stock = $req_check->fetch();

        if($existing_stock){
            $new_qte = (float)$existing_stock['quantity'] + $qte;
            $req_upd_wall = $pdo->prepare("UPDATE wallet SET quantity = :qte WHERE id_wall = :id_wall");
            $req_upd_wall->execute([':qte' => $new_qte, ':id_wall' => $existing_stock['id_wall']]);
        } else {
            $req_ins = $pdo->prepare("INSERT INTO wallet (id_user, name_action, symbol_action, prix_achat, quantity) VALUES (:id_user, :name, :symbol, :prix, :qte)");
            $req_ins->execute([
                ':id_user' => $user_data['id_user'],
                ':name' => $symbol, 
                ':symbol' => $symbol,
                ':prix' => $prix_actuel,
                ':qte' => $qte
            ]);
        }
        $message = "<div class='alert alert-success'>Achat de $qte action(s) $symbol réussi ! Nouveau solde: " . number_format($new_solde, 2, ',', ' ') . " €</div>";
    } else {
        $message = "<div class='alert alert-warning'>Fonds insuffisants ou quantité invalide.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <title>Marché</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container-fluid">
    <div class="row">
        <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse min-vh-100">
            <div class="position-sticky pt-3">
                <h5 class="text-white px-3 mb-4">StockManager</h5>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="wallet.php">Wallet</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white active" href="marche.php">Marché</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="compte.php">Compte</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="retrait.php">
                           Retrait/Dêpot
                        </a>
                    </li>
                    <li class="nav-item">
                        <form method="post" class="nav-link text-danger mt-5">
                            <input type="submit" value="Déconnexion" name="sub" class="btn btn-outline-danger btn-sm"/>
                        </form>
                    </li>
                </ul>
            </div>
        </nav>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="pt-3 pb-2 mb-3 border-bottom d-flex justify-content-between align-items-center">
                <h1 class="h2">Marché Boursier</h1>
            </div>
            
            <?= $message ?>

            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <form method="get" class="d-flex gap-2">
                        <input type="text" name="symbol" class="form-control" placeholder="Rechercher un symbole (Ex: AAPL)" value="<?= htmlspecialchars($searched_symbol) ?>" required>
                        <button class="btn btn-dark" type="submit">Chercher</button>
                    </form>
                </div>
            </div>

            <?php if($searched_price > 0 && !empty($searched_symbol)): ?>
            <div class="row">
                <div class="col-lg-8 mb-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-white d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Évolution : <?= htmlspecialchars($searched_symbol) ?></h5>
                            <div class="btn-group btn-group-sm" role="group">
                                <button type="button" class="btn btn-outline-secondary active" onclick="updateChart('month', this)">1 Mois</button>
                                <button type="button" class="btn btn-outline-secondary" onclick="updateChart('year', this)">1 An</button>
                            </div>
                        </div>
                        <div class="card-body">
                            <canvas id="stockChart"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 mb-4">
                    <div class="card shadow-sm border-primary h-100">
                        <div class="card-header bg-primary text-white py-3">
                            <h5 class="mb-0">Acheter</h5>
                        </div>
                        <div class="card-body text-center">
                            <p class="text-muted mb-1 small">Prix Actuel</p>
                            <h2 class="mb-4 text-primary"><?= number_format($searched_price, 2, ',', ' ') ?> €</h2>
                            
                            <form method="post">
                                <input type="hidden" name="symbol" value="<?= htmlspecialchars($searched_symbol) ?>">
                                <input type="hidden" name="prix" value="<?= $searched_price ?>">
                                
                                <div class="mb-3 text-start">
                                    <label class="form-label fw-bold">Quantité</label>
                                    <input type="number" name="qte" class="form-control form-control-lg"  min="1" value="1" id="qteInput" required>
                                </div>

                                <div class="mb-4 text-start bg-light p-2 rounded">
                                    <small class="text-muted">Total estimé : <strong id="totalCost"><?= number_format($searched_price, 2, ',', ' ') ?></strong> €</small>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" name="acheter" class="btn btn-success btn-lg">Acheter</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </main>
    </div>
    </div>

    <script>
        const symbol = "<?= htmlspecialchars($searched_symbol) ?>";
        const currentPrice = <?= $searched_price ?: 0 ?>;
        let chartInstance = null;

        // Calcul dynamique du total à l'achat
        const qteInput = document.getElementById('qteInput');
        const totalCostSpan = document.getElementById('totalCost');
        if(qteInput && totalCostSpan) {
            qteInput.addEventListener('input', function() {
                const total = this.value * currentPrice;
                totalCostSpan.textContent = total.toLocaleString('fr-FR', {minimumFractionDigits: 2, maximumFractionDigits: 2});
            });
        }

        // Fonction fetch (Service Web) pour récupérer les données et dessiner le graphique
        function updateChart(range, btnElement = null) {
            if(!symbol) return;

            // Mise à jour de l'UI des boutons
            if(btnElement) {
                document.querySelectorAll('.btn-group .btn').forEach(b => b.classList.remove('active'));
                btnElement.classList.add('active');
            }

            // Appel au web service PHP (ce fichier lui-même, en haut)
            fetch(`marche.php?action=get_chart_data&symbol=${symbol}&range=${range}`)
                .then(response => response.json())
                .then(data => {
                    if(data.error) {
                        console.error(data.error);
                        return;
                    }

                    const ctx = document.getElementById('stockChart').getContext('2d');
                    
                    if(chartInstance) {
                        chartInstance.destroy(); // Détruire l'ancien graphique avant d'en redessiner un
                    }

                    chartInstance = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: data.labels,
                            datasets: [{
                                label: `Cours de ${symbol} (${range === 'month' ? '30 jours' : '1 an'})`,
                                data: data.prices,
                                borderColor: 'rgba(13, 110, 253, 1)', // Bleu bootstrap
                                backgroundColor: 'rgba(13, 110, 253, 0.1)',
                                borderWidth: 2,
                                fill: true,
                                tension: 0.1,
                                pointRadius: 2
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: false
                                }
                            }
                        }
                    });
                })
                .catch(error => console.error("Erreur lors de la récupération des données:", error));
        }

        // Charger le graphique par défaut (1 mois) si un symbole est cherché
        if(symbol) {
            updateChart('month');
        }
    </script>
</body>
</html>