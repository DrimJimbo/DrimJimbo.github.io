<?php
    include_once "../includes/functions.php";
    session_start();
    global $pdo;
    if(isset($_POST['sub'])){
        session_destroy();
    }
    if(!isset($_SESSION['user'])){
        header("Location: index.php");
    }
    if(isset($_POST['update_profile'])){
        if(isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === 0){
            $namepic = downloadPic($_FILES['profile_pic'],$_SESSION['user']);
        }
        else{
            $namepic = null;
        }
        $name = $_POST['name'];
        $surname = $_POST['surname'];
        $mail = $_POST['email'];
        $date = $_POST['birth_date'];
        $gender = $_POST['gender'];
        $marital =  $_POST['marital_status'];
        changeUser($_SESSION['user'],$namepic,$name,$surname,$mail,$date,$gender,$marital);
    }
    $query = "SELECT * FROM users WHERE username = :user";
    $request = $pdo->prepare($query);
    try{
        $request->execute([
            ":user" => $_SESSION['user'],
        ]);
        $user = $request->fetch();
    }catch (PDOException $e){
        die("probleme de recuperation de l'utilisateur ".$e->getMessage());
    }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <title>Wallet</title>
</head>
<body>
    <div class="container-fluid">
    <div class="row">
        <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse min-vh-100">
            <div class="position-sticky pt-3">
                <h5 class="text-white px-3 mb-4">StockManager</h5>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link text-white active" href="wallet.php">
                            <i class="bi bi-house-door"></i> Wallet
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="marche.php">
                            <i class="bi bi-wallet2"></i> Marché
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="compte.php">
                            <i class="bi bi-graph-up-arrow"></i> Compte
                        </a>
                    </li>
                    <li class="nav-item">
                        <form  method="post" class="nav-link text-danger mt-5" href="logout.php">
                            <input type="submit" value="Déconnexion" name="sub" class="btn btn-outline-danger btn-sm d-flex align-items-center gap-2"/>
                        </form>
                    </li>
                </ul>
            </div>
        </nav>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Modifier mon profil</h1>
        <a href="compte.php" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left"></i> Annuler
        </a>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-body p-4">
                    <form  method="POST" enctype="multipart/form-data">
                        
                        <div class="col-12 mb-4 text-center text-md-start">
                            <label class="form-label fw-bold d-block">Photo de profil</label>
                            <div class="d-flex flex-column flex-md-row align-items-center gap-4">
                                <div class="position-relative">
                                    <img src="<?= $user['path_avatar'] ?>" 
                                         class="rounded-circle img-thumbnail shadow-sm" 
                                         style="width: 120px; height: 120px; object-fit: cover;" 
                                         id="preview">
                                </div>
                                
                                <div class="flex-grow-1 w-100">
                                    <input type="file" name="profile_pic" class="form-control" id="inputProfilePic" accept="image/*">
                                    <div class="form-text mt-2">
                                        <i class="bi bi-info-circle"></i> Formats acceptés : JPG, PNG ou GIF. Taille max : 2 Mo.
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr class="my-4">

                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Prénom</label>
                                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-bold">Nom</label>
                                <input type="text" name="surname" class="form-control" value="<?= htmlspecialchars($user['surname']) ?>" required>
                            </div>

                            <div class="col-12">
                                <label class="form-label fw-bold">Adresse Email</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-envelope"></i></span>
                                    <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-bold">Genre</label>
                                <select name="gender" class="form-select">
                                    <option value="Homme" <?= $user['gender'] == 'male' ? 'selected' : '' ?>>Homme</option>
                                    <option value="Femme" <?= $user['gender'] == 'female' ? 'selected' : '' ?>>Femme</option>
                                    <option value="Ne souhaite pas répondre" <?= $user['gender'] == 'prefer_not_to_say' ? 'selected' : '' ?>>Ne souhaite pas répondre</option>
                                </select>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-bold">Date de naissance</label>
                                <input type="date" name="birth_date" class="form-control" value="<?= $user['birth_date'] ?>">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-bold">Statut Marital</label>
                                <select name="marital_status" class="form-select">
                                    <option value="Célibataire" <?= $user['marital_status'] == 'Célibataire' ? 'selected' : '' ?>>Célibataire</option>
                                    <option value="Marié(e)" <?= $user['marital_status'] == 'Marié(e)' ? 'selected' : '' ?>>Marié(e)</option>
                                    <option value="Pacsé(e)" <?= $user['marital_status'] == 'Pacsé(e)' ? 'selected' : '' ?>>Pacsé(e)</option>
                                    <option value="Divorcé(e)" <?= $user['marital_status'] == 'Divorcé(e)' ? 'selected' : '' ?>>Divorcé(e)</option>
                                </select>
                            </div>

                            <div class="col-12 mt-5 pt-3 border-top">
                                <div class="d-flex justify-content-end gap-3">
                                    <input type="submit" name="update_profile" class="btn btn-primary px-5 py-2 fw-bold" value="Mettre à jour le profil" />
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
</div>
</div>
</body>
</html>