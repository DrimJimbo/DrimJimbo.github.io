<?php
    include_once "../includes/functions.php";
    session_start();
    global $pdo;
    if(isset($_POST['sub'])){
        session_destroy();
    }
    if(!isset($_SESSION['user'])){
        header("Location: index.php");
    }
    if(isset($_POST['change'])){
        $current = $_POST['current'];
        $new = $_POST['new'];
        $confirm = $_POST['confirm'];
        $query = "SELECT * FROM users WHERE username = :user";
        $request = $pdo->prepare($query);
        try{
            $request->execute([
                ":user" => $_SESSION['user'] 
            ]);
            $res = $request->fetch();
            if(password_verify($current,$res['password']) && $new == $confirm){
                $query = "UPDATE users SET password = :pass";
                $request = $pdo->prepare($query);
                $request->execute([
                    ":pass" => password_hash($new, PASSWORD_DEFAULT),
                ]);
            }
        }catch (PDOException $e){
            die("Erreur lors de la récupération : ".$e->getMessage());
        }
    }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <title>Wallet</title>
</head>
<body>
    <div class="container-fluid">
    <div class="row">
        <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse min-vh-100">
            <div class="position-sticky pt-3">
                <h5 class="text-white px-3 mb-4">StockManager</h5>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link text-white active" href="wallet.php">
                            <i class="bi bi-house-door"></i> Wallet
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="marche.php">
                            <i class="bi bi-wallet2"></i> Marché
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="compte.php">
                            <i class="bi bi-graph-up-arrow"></i> Compte
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="retrait.php">
                            <i class="bi bi-graph-up-arrow"></i> Retrait/Dêpot
                        </a>
                    </li>
                    <li class="nav-item">
                        <form  method="post" class="nav-link text-danger mt-5" href="logout.php">
                            <input type="submit" value="Déconnexion" name="sub" class="btn btn-outline-danger btn-sm d-flex align-items-center gap-2"/>
                        </form>
                    </li>
                </ul>
            </div>
        </nav>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Modifier mon mot de passe</h1>
        <a href="compte.php" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left"></i> Annuler
        </a>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-body p-4">
                    <form   method="POST" enctype="multipart/form-data">
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Mot de passe current : </label>
                            <input class="form-text" type='password' name='current' required/>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Nouveau mot de passe : </label>
                            <input class="form-text" type='password' name='new' required/>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Confirmer votre mot de passe :</label>
                            <input class="form-text" type='password' name='confirm' required/> 
                        </div>
                        <div class="col-12 mt-5 pt-3 border-top">
                            <input class="btn btn-danger px-4" type="submit" name='change' value="Confirmer"/>
                            <?= isset($_POST['change']) ? '<label class="form-label text-success">Mot de passe changé !</label>' : '' ?> 
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
</div>
</div>
</body>
</html>