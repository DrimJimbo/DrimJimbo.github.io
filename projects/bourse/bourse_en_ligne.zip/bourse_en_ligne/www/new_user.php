<?php
require_once __DIR__."/../includes/functions.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
  // Validation côté serveur
  if ($_POST["passwordInput"] !== $_POST["passwordConfirmInput"]) {
    header("Location: ".$_SERVER['PHP_SELF']."?code_error=1");
    exit();
  }

  if (!estMajeur($_POST['birthDateInput'])){
    header("Location: ".$_SERVER['PHP_SELF']."?code_error=2"); 
    exit();
  }

  if (valueExist("users", "email", $_POST['emailInput'])){
    header("Location: ".$_SERVER['PHP_SELF']."?code_error=3");
    exit();
  }

  if (valueExist("users", "username", $_POST['usernameInput'])){
    header("Location: ".$_SERVER['PHP_SELF']."?code_error=4");
    exit();
  }

  addUser(
    $_POST['usernameInput'], 
    $_POST['emailInput'], 
    $_POST['passwordInput'], 
    $_POST['nameInput'], 
    $_POST['surnameInput'], 
    $_POST['maritalStatusInput'], 
    $_POST['genderInput'], 
    $_POST['birthDateInput']
  );
  header('Location: index.php?success=1');
  exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="/css/main.css">
  <title>Nouvel utilisateur</title>
</head>
<body>
  <main>
    <form action="" method="post">
      <fieldset>
        <legend>Créer un compte</legend>

        <div class="input"><label for="usernameInput">Nom d'utilisateur</label><input type="text" name="usernameInput" id="usernameInput" required></div>
        <div class="input"><label for="emailInput">Email</label><input type="email" name="emailInput" id="emailInput" required></div>
        <div class="input"><label for="passwordInput">Mot de passe</label><input type="password" name="passwordInput" id="passwordInput" required></div>
        <div class="input"><label for="passwordConfirmInput">Confirmez le mot de passe</label><input type="password" name="passwordConfirmInput" id="passwordConfirmInput" required></div>
        <div class="input"><label for="nameInput">Prénom</label><input type="text" name="nameInput" id="nameInput" required></div>
        <div class="input"><label for="surnameInput">Nom</label><input type="text" name="surnameInput" id="surnameInput" required></div>

        <fieldset>
          <legend>État-civil</legend>
          <div><input type="radio" name="maritalStatusInput" value="single" id="single" checked><label for="single">Célibataire</label></div>
          <div><input type="radio" name="maritalStatusInput" value="married" id="married"><label for="married">Marié(e)</label></div>
          <div><input type="radio" name="maritalStatusInput" value="civil_partnership" id="civil_partnership"><label for="civil_partnership">Pacsé</label></div>
          <div><input type="radio" name="maritalStatusInput" value="divorced" id="divorced"><label for="divorced">Divorcé(e)</label></div>
          <div><input type="radio" name="maritalStatusInput" value="widowed" id="widowed"><label for="widowed">Veuf(ve)</label></div>
        </fieldset>

        <fieldset>
          <legend>Genre</legend>
          <div><input type="radio" name="genderInput" value="male" id="male"><label for="male">Homme</label></div>
          <div><input type="radio" name="genderInput" value="female" id="female"><label for="female">Femme</label></div>
          <div><input type="radio" name="genderInput" value="prefer_not_to_say" id="notSaying" checked><label for="notSaying">Ne souhaite pas répondre</label></div>
        </fieldset>

        <div class="input"><label for="birthDateInput">Date de naissance</label><input type="date" name="birthDateInput" id="birthDateInput"></div>
        
        <input type="submit" value="Créer le compte">

        <?php
          if (isset($_GET['code_error'])) {
            $messages = [
              '1' => 'Les mots de passe doivent être identiques.',
              '2' => 'Vous devez être majeur pour créer un compte.',
              '3' => 'Cet email est déjà utilisé.',
              '4' => 'Ce nom d\'utilisateur est déjà pris.'
            ];
            $msg = $messages[$_GET['code_error']] ?? 'Une erreur inconnue est survenue.';
            echo '<p class="error">' . $msg . '</p>';
          }
        ?>
      </fieldset>
    </form>
    <section><a href="index.php">Retour à la connexion</a></section>
  </main>
</body>
</html>