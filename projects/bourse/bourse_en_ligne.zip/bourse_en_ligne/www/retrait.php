<?php
    include_once "../includes/functions.php";
    session_start();
    global $pdo;
    if(!isset($_SESSION['user'])){
        header('Location: index.php');
        exit();
    }
    $query = "SELECT * FROM users WHERE username = :user";
    $request = $pdo->prepare($query);
    try{
        $request->execute([
            ":user" => $_SESSION['user'],
        ]);
        $res = $request->fetch();
    }catch (PDOException $e){
        die("Erreur Recup user : ".e->getMessage());
    }
    if(isset($_POST['depot'])){
        deposer($_SESSION['user'],$_POST['amount'],$res['value_wallet']);
    }
    if(isset($_POST['retrait'])){
        retirer($_SESSION['user'],$_POST['amount2'],$res['value_wallet']);
    }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <title>Vendre</title>
</head>
<body>
    <div class="container-fluid">
    <div class="row">
        <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse min-vh-100">
            <div class="position-sticky pt-3">
                <h5 class="text-white px-3 mb-4">StockManager</h5>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link text-white active" href="wallet.php">
                             Wallet
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="marche.php">
                            Marché
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="compte.php">
                             Compte
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="retrait.php">
                             Retrait/Dêpot
                        </a>
                    </li>
                    <li class="nav-item">
                        <form  method="post" class="nav-link text-danger mt-5">
                            <input type="submit" value="Déconnexion" name="sub" class="btn btn-outline-danger btn-sm d-flex align-items-center gap-2"/>
                        </form>
                    </li>
                </ul>
            </div>
        </nav>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Gestion du solde</h1>
        <div class="badge bg-primary fs-5 p-2">
            Solde actuel : <?= number_format($res['value_wallet'], 2, ',', ' ') ?> €
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <ul class="nav nav-tabs card-header-tabs" id="transactionTab" role="tablist">
                        <li class="nav-item">
                            <button class="nav-link active fw-bold text-success" id="deposit-tab" data-bs-toggle="tab" data-bs-target="#deposit" type="button" role="tab">
                                <i class="bi bi-plus-circle"></i> Déposer
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link fw-bold text-danger" id="withdraw-tab" data-bs-toggle="tab" data-bs-target="#withdraw" type="button" role="tab">
                                <i class="bi bi-dash-circle"></i> Retirer
                            </button>
                        </li>
                    </ul>
                </div>
                
                <div class="card-body p-4">
                    <div class="tab-content" id="transactionTabContent">
                        
                        <div class="tab-pane fade show active" id="deposit" role="tabpanel">
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Montant à créditer</label>
                                    <div class="input-group input-group-lg">
                                        <input type="number" name="amount" class="form-control" placeholder="0.00" min="1" step="0.01" required>
                                        <span class="input-group-text">€</span>
                                    </div>
                                    <div class="form-text">L'argent sera instantanément ajouté à votre portefeuille virtuel.</div>
                                </div>
                                <input type="submit" class="btn btn-success w-100 py-2" value="Confirmer le dépôt" name="depot"/>
                            </form>
                        </div>

                        <div class="tab-pane fade" id="withdraw" role="tabpanel">
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Montant à retirer</label>
                                    <div class="input-group input-group-lg">
                                        <input type="number" name="amount2" class="form-control" placeholder="0.00" min="0.01" max="<?= $res['value_wallet'] ?>" step="0.01" required>
                                        <span class="input-group-text">€</span>
                                    </div>
                                    <div class="form-text text-danger">Le montant ne peut pas dépasser votre solde disponible.</div>
                                </div>
                                <input type="submit" class="btn btn-danger w-100 py-2" value="Confirmer le retrait" name="retrait">
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        
</div>
</div>
</body>
</html>
        