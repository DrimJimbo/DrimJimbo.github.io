<?php
    include_once "../includes/functions.php";
    session_start();
    global $pdo;
    $id= $_SESSION['id'];
    if(!isset($_SESSION['id'])){
        header("Location: wallet.php");
    }
    $query = "SELECT * FROM wallet WHERE id_wall = :id";
    $request = $pdo->prepare($query);
    try{
        $request->execute([
            ":id" => $id,
        ]);
        $res=$request->fetch();
    }catch (PDOException $e){
        die("Erreur lors de la vente : ".e->getMessage());
    }
    $price = getPrice($res['symbol_action']);
    if(isset($_POST['vendre'])){
        $qte = $_POST['num'];
        vendre($id,$qte,$price);
        header("Location: wallet.php");
    }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <title>Vendre</title>
</head>
<body>
    <div class="container-fluid">
    <div class="row">
        <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse min-vh-100">
            <div class="position-sticky pt-3">
                <h5 class="text-white px-3 mb-4">StockManager</h5>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link text-white active" href="wallet.php">
                             Wallet
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="marche.php">
                             Marché
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="compte.php">
                             Compte
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="retrait.php">
                             Retrait/Dêpot
                        </a>
                    </li>
                    <li class="nav-item">
                        <form  method="post" class="nav-link text-danger mt-5">
                            <input type="submit" value="Déconnexion" name="sub" class="btn btn-outline-danger btn-sm d-flex align-items-center gap-2"/>
                        </form>
                    </li>
                </ul>
            </div>
        </nav>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="pt-3 pb-2 mb-3 border-bottom d-flex justify-content-between align-items-center">
        <h1 class="h2">Bienvenue, <?php echo htmlspecialchars($_SESSION['user']) ?></h1>
        <span class="badge bg-primary fs-6">Mode Vente</span>
    </div>

    <div class="row justify-content-center mt-4">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="card-title mb-0 text-dark">
                        Vendre mes actions <span class="text-primary"><?php echo $res['symbol_action'] ?></span>
                    </h5>
                    <small class="text-muted"><?php echo $res['name_action'] ?></small>
                </div>
                
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between mb-4">
                        <div class="text-center p-2 flex-fill border-end">
                            <p class="text-muted mb-1 small uppercase">Prix Actuel</p>
                            <span class="h5 mb-0" id="price"><?php echo $price?></span> €
                        </div>
                        <div class="text-center p-2 flex-fill">
                            <p class="text-muted mb-1 small uppercase">En possession</p>
                            <span class="h5 mb-0"><?php echo $res['quantity'] ?></span> unités
                        </div>
                    </div>

                    <form method="post">
                        <div class="mb-4">
                            <label for="qte" class="form-label fw-bold">Quantité à vendre</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-hash"></i></span>
                                <input id="qte" type="number" name="num" 
                                       class="form-control form-control-lg" 
                                       min="1" max="<?php echo $res['quantity'] ?>" 
                                       value="1" required>
                            </div>

                        </div>

                        <div class="alert alert-secondary border-0 bg-light py-3">
                            <div class="d-flex justify-content-center align-items-center">
                                <span class="h4 mb-0 text-success" id="gain"></span>
                            </div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" name="vendre" class="btn btn-danger btn-lg">
                                Confirmer la vente
                            </button>
                            <a href="wallet.php" class="btn btn-link text-muted">Annuler et revenir au wallet</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
</div>
</div>
 <script src="js/gainfunction.js"></script>
</body>
</html>
        