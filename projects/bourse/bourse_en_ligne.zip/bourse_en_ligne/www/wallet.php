<?php
    require_once "../includes/functions.php";
    session_start();
    if(isset($_POST['vendre'])){
        $_SESSION['id'] = $_POST['id'];
        header("Location: vendre.php");
    }
    if(isset($_POST['sub'])){
        session_destroy();
        header("Location: index.php");
        exit();
    }
    if(!isset($_SESSION['user'])){
        header("Location: index.php");
        exit();
    }
    $solde = 0;
    global $pdo;
    $query = "SELECT value_wallet FROM users WHERE username = :user";
    $request = $pdo->prepare($query);
    try {
        $user = $_SESSION['user'];
        $request->execute([
            ':user' => $user,
        ]);
        $result = $request->fetch();
        $solde = $result ? $result['value_wallet'] : 0;
    } catch (PDOException $e){
        die("Erreur SQL : " . $e->getMessage());
    }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <title>Wallet</title>
</head>
<body>
    <div class="container-fluid">
    <div class="row">
        <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse min-vh-100">
            <div class="position-sticky pt-3">
                <h5 class="text-white px-3 mb-4">StockManager</h5>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link text-white active" href="wallet.php">
                             Wallet
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="marche.php">
                            Marché
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="compte.php">
                             Compte
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="retrait.php">
                             Retrait/Dêpot
                        </a>
                    </li>
                    <li class="nav-item">
                        <form  method="post" class="nav-link text-danger mt-5" href="logout.php">
                            <input type="submit" value="Déconnexion" name="sub" class="btn btn-outline-danger btn-sm d-flex align-items-center gap-2"/>
                        </form>
                    </li>
                </ul>
            </div>
        </nav>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="pt-3 pb-2 mb-3 border-bottom d-flex justify-content-between align-items-center">
                <h1 class="h2">Bienvenue, <?php echo $_SESSION['user']?></h1>
                <h1 class="h2">Wallet</h1>
            </div>
            <h2>Solde : <?php echo number_format($solde, 2, '.', ' ')."€"?></h2>
            <div class="table-responsive">
            <table class="table table-hover align-middle border-top">
                <thead class="table-light">
                    <tr>
                        <th>Nom</th>
                        <th>Symbole</th>
                        <th class="text-center">Quantité</th>
                        <th>Prix d'achat</th>
                        <th>Prix actuel</th>
                        <th>Valeur</th>
                        <th>Profit</th>
                        <th>Vendre</th>
                    </tr>
                </thead>
                <tbody>
            <?php 
                $query = "SELECT wallet.*, users.username, users.value_wallet FROM wallet JOIN users ON wallet.id_user = users.id_user WHERE users.username = :username";
                $request = $pdo->prepare($query);
                try{
                    global $api_aym;
                    $request->execute([":username" => $_SESSION['user']]);
                    // On récupère tout d'un coup pour pouvoir compter
                    $rows = $request->fetchAll(PDO::FETCH_ASSOC);
                    if (count($rows) > 0) {
                        foreach ($rows as $res) {
                            $prix_achat = $res['prix_achat'] ?? 0;
                            $symbol = $res['symbol_action'];
                            $price = getPrice($symbol);
                            $valeur = $price * $res['quantity'];
                            $profit = $valeur - ($prix_achat*$res['quantity']);
                            $id_trans = $res['id_wall'];
                            echo "<tr>
                                    <td class='fw-bold'>" . htmlspecialchars($res['name_action']) . "</td>
                                    <td><span class='badge bg-dark'>" . htmlspecialchars($res['symbol_action']) . "</span></td>
                                    <td class='text-center'>{$res['quantity']}</td>
                                    <td>" . number_format($prix_achat, 2, ',', ' ') . " €</td>
                                    <td class='text-muted italic'>$price</td>
                                    <td class='fw-bold text-primary'>" . number_format($valeur, 2, ',', ' ') . " €</td>
                                    <td class='text-success'>$profit</td>
                                    <td>
                                        <form method='post'>
                                            <input type='hidden' name='id' value=$id_trans /> 
                                            <input type='submit' name='vendre' value='Vendre' class='btn btn-outline-danger btn-sm d-flex align-items-center gap-2 '>
                                        </form>
                                    </td>
                                </tr>";

                        }
                    } else {
                        echo "<tr><td colspan='7' class='text-center py-4 text-muted'>Vous ne possédez aucune action pour le moment.</td></tr>";
    }
                }catch (PDOException $e){
                    die("Erreur affichage wallet: " . $e->getMessage());
                }
            ?>
                </tbody>
            </table>           
        </main>
    </div>
</div>
</body>
</html>