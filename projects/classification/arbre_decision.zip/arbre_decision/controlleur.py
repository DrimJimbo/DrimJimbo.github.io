from modele import *
from vue import *

def main():
    window = Interface(720,480,"Ceci est un test","#a663c1")
main()