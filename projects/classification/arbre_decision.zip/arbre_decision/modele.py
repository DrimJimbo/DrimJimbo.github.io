import csv
import pandas as pd
from typing import List,Dict,Union,Any,Tuple


# Class CSVFile
class CSVFile():
    # Construtor
    def __init__(self,path:str) -> 'CSVFile':
        """
        Constructor CSVFile class
        str(path) -> object(CSVFile)
        """
        self.__path = path
        self.read() # read CSVFile and create self.__list -> liste of argument of CSVFile 
        self.create_list_type()
        self.__target = self.__list[0][len(self.__list[0])-1] # index of target column 
        self.__depthMax = 10 # depth max of BinaryTree
        self.__exampleMax = 10 # Example max 
        self.d = self.create_dic(self.__list)
        node = Node(element=self.d)
        self.__tree = binaryTree(node)


    def get_target(self,target:str) -> int:
        """
        return index of target
        CSVFile, str(target) -> int
        """
        for i in range(0,len(self.__list[0])):
            if self.__list[0][i] == target:
                print(i)
                return i
        return -1

    # Reader of CSVFile 
    def read(self) -> List[List[Any]]:
        """
        read CSV file 
        CSVFile -> liste[List[Any]]
        """
        if(self.__path == ""):
            return []
        else :
            with open(self.__path, mode='r') as file:
                reader = csv.reader(file)
                l = []
                for i in reader:
                    l.append(i)
                self.__list = l
                return l
            
    def get(self):
        return self.__target
            
    def value_binary(self,indice:int) -> bool:
        """
        return true if column have two value 
        CSVFile, int(indice) -> bool
        """
        sum_value = 0
        list_value = []
        for i in range(1,len(self.__list)):
            if self.__list[i][indice] not in list_value :
                list_value.append(self.__list[i][indice])
                sum_value += 1
        return sum_value == 2
    
    def to_int(self,ch:str) -> bool :
        """
        return treu if ch to int 
        CSVFile, str(ch) -> bool
        """
        try:
            int(ch)  # Try to convert to integer
            return True
        except ValueError:
            return False
    
    def to_float(self,ch:str) -> bool :
        """
        return treu if ch to int 
        CSVFile, str(ch) -> bool
        """
        try:
            float(ch)  # Try to convert to float
            return True
        except ValueError:
            return False
    
    def type_value(self,index) -> str:
        """
        return type of value 
        CSVFile, int(index) -> str
        """
        t = None
        for i in range(1,len(self.__list)):
            value = self.__list[i][index]
            if self.to_int(value) :
                te = "int"
            elif self.to_float(value) :
                te = "float"
            else :
                te = "str"
            if te != t and t != None :
                return "str"
            if t == None :
                t = te
        return t
    
    def create_list_type(self):
        """
        Create liste with good type
        CSVFile -> liste
        """
        l = [[] for i in range(1,len(self.__list))]
        for j in range(0,len(self.__list[0])):
            for i in range(1,len(self.__list)):
                type = self.type_value(j)
                if type == "str" :
                    l[i-1].append(self.__list[i][j])
                elif type == "float" :
                    l[i-1].append(float(self.__list[i][j]))
                elif type == "int" :
                    l[i-1].append(int(self.__list[i][j]))
        l.insert(0,self.__list[0])
        self.__list = l

    def list_sep(self,liste)->List[Any]:
        """
        return liste of seperation Example : [[NameCol,ValueOfSep,index]]
        CSVFile -> List[List[Any]]
        """
        list_of_sep = []
        for i in range(0,len(liste[0])-1):
            for j in range(1,len(liste)):
                tuple_nomCol_value = [liste[0][i],None,i]
                tuple_nomCol_value[1] = liste[j][i]
                if tuple_nomCol_value not in list_of_sep :
                    list_of_sep.append(tuple_nomCol_value)
        return list_of_sep
    
    def freq(self,indice:int,value:Any)->List[Dict]:
        """
        return frequence of value in column 
        CSVFile, int, Any -> List[Dict{value : int, Total : int },Dict{otherValue : int , Total : int}]
        """
        l_freq = []
        d = {}
        d2 = {}
        sum = 0
        sum2 = 0
        for i in range(1,len(self.__list)):
            if self.__list[i][indice] == value or self.__list[i][indice] < value:
                sum += 1
                v = self.__list[i][len(self.__list[0])-1]
                if v in d :
                    d[v] += 1
                else :
                    d[v] = 1
            else :
                sum2 += 1
                v = self.__list[i][len(self.__list[0])-1]
                if v in d2 :
                    d2[v] += 1
                else :
                    d2[v] = 1
        d['Total'] = sum
        d2['Total'] = sum2
        l_freq.append(d)
        l_freq.append(d2)
        return l_freq
            

    def list_gini(self,list_sep:List[Any])->List[int]:
        """
        return liste of gini index 
        CSVFile, List[Any] -> List[int]
        """
        list_gini = []
        list_freq = []
        list_gini_total = []
        for i in list_sep :
            freq = self.freq(i[2],i[1])
            list_freq.append(freq)
        for i in list_freq :
            gini = 1
            gini2 = 1
            for j in i[0] :
                if j != 'Total':
                    gini -= (i[0][j]/i[0]['Total'])**2
            for j in i[1] :
                if j != 'Total':
                    gini2 -= (i[1][j]/i[1]['Total'])**2
            list_gini.append([gini,gini2])
        for i in range(0,len(list_gini)) :
            total_gini = (list_freq[i][0]['Total'] / (len(self.__list)-1)) * list_gini[i][0]
            total_gini += (list_freq[i][1]['Total'] / (len(self.__list)-1)) * list_gini[i][1]
            list_gini_total.append(total_gini)
        return list_gini_total
    
    def min_index(self,liste:List[int]) -> int :
        """
        return index of min 
        CSVFile, liste[int] -> int
        """
        min = liste[0]
        ind = 0
        for i in range(1,len(liste)):
            if min > liste[i] and liste[i] != None:
                min = liste[i]
                ind = i
        return ind
    
    def create_dic(self,liste:List)->Dict:
        """
        return dict of donnée {Name : pourcentage}
        CSVFile, List[List[Any]] -> Dict{Name : pourcentage}
        """
        j = len(liste[0]) -1
        d = {}
        for i in range(1,len(liste)):
            value = liste[i][j]
            if value in d :
                d[value] += 1
            else :
                d[value] = 1
        for i in d:
            d[i] = d[i]/(len(liste)-1)
            d[i] *= 100
        return d

    def createList(self,list_sep:List,liste)->List[List[any]] :
        """
        return 2 List , ListInferieurEqual , ListSuperieur
        CSVFile, List[Any], List[List[Any]] -> List[List[Any]]
        """
        listInferieurEqual = [liste[0]]
        listSuperieur = [liste[0]]
        for i in range(1,len(liste)):
            li = []
            ls = []
            if liste[i][list_sep[2]] <= list_sep[1] :
                for j in range(0,len(liste[i])):
                    li.append(liste[i][j])
                listInferieurEqual.append(li)
            else :
                for j in range(0,len(liste[i])):
                    ls.append(liste[i][j])
                listSuperieur.append(ls)
        return [listInferieurEqual,listSuperieur]
    
    def cent(self,d):
        for i in d:
            if d[i] == 100 :
                return True
        return False
            
    def CART(self,liste=None,n = 0):
        """
        create node and use CART algo
        CSVFile, List[List[Any]], int -> Node
        """
        if liste == None :
            liste = self.__list
            node = self.__tree.get()
            d = self.d
        else : 
            d = self.create_dic(liste)
            node = Node(d)
        if n == self.__depthMax or len(liste) == 1:
            return None
        if not self.cent(d):
            list_sep = self.list_sep(liste)
            list_gini = self.list_gini(list_sep)
            ind = self.min_index(list_gini)
            lists = self.createList(list_sep[ind],liste)
            node.setConditon(list_sep[ind])
            node.setFG(self.CART(lists[0],n+1))
            node.setFD(self.CART(lists[1],n+1))
        return node

    def print_tree(self)->str:
        """
        return self.__tree.toString() after CART algo
        CSVfile -> str
        """
        n = self.CART()
        return self.__tree.toString()

# Class of Node
class Node():

    def __init__(self,element:Dict,fg:"Node"=None,condition:List=None,fd:"Node"=None):
        """
        Constructor of Node class
        Node , Dict{Name:int}(element) , Node(fg,fd) -> Node
        """
        self.__element = element
        self.__condition = condition
        self.__fg = fg
        self.__fd = fd

    def get_depth(self):
        """
        Return max depth of binaryTree
        Node -> int
        """
        lDepth = self.__fg.get_depth() if self.__fg else 0
        rDepth = self.__fd.get_depth() if self.__fd else 0
        return max(lDepth, rDepth) + 1
    
    def fg(self)-> "Node":
        """
        return fg of Node
        Node -> Node
        """
        return self.__fg
    
    def fd(self)-> "Node":
        """
        return fd of Node
        Node -> Node
        """
        return self.__fd
    
    def setFG(self,node:"Node")-> None:
        """
        Set fg of Node
        Node ,Node -> None
        """
        self.__fg = node

    def setFD(self,node:"Node")-> None:
        """
        Set fg of Node
        Node ,Node -> None
        """
        self.__fd = node

    def setConditon(self,liste:List)-> None:
        """
        Set fg of Node
        Node ,List[Name,value] -> None
        """
        self.__condition = liste

    def toString(self, depth: int = 0) -> str:
        """
        Print Node
        """ 
        prefix = " " * depth * 2
        result = f"{prefix}{self.__element})\n"
        if self.__fg !=  None:
            result += f"{prefix} Left -> {self.__condition[0]} <= {self.__condition[1]} {self.__fg.toString(depth + 1)}"
        if self.__fd != None:
            result += f"{prefix} Right -> {self.__condition[0]} > {self.__condition[1]} {self.__fd.toString(depth + 1)}"
        return result

# Class of binaryTree
class binaryTree():

    def __init__(self,head:"Node"= None):
        """
        Constructor of binaryTree class
        binaryTree , Node -> binaryTree
        """
        self.__head = head
    
    def is_empty(self) -> bool:
        """
        Return true if binaryTree is empty
        binaryTree -> Bool
        """
        return self.__head == None
    
    def get_depth(self) -> int :
        """
        get the depth of binaryTree
        binaryTree -> int
        """
        if(self.is_empty()):
            return -1
        return self.__head.get_depth()
    
    def get(self):
        return self.__head
    
    def toString(self) -> str:
        """
        print binaryTree
        binaruTree -> str
        """
        if self.is_empty():
            return "Binary Tree is empty."
        return self.__head.toString()

    
    

#c = CSVFile("C:/Users/aymer/OneDrive/Documents/Ecole/Licence/2eme Licence (2)/1er Semestre/Algo3/Projet/iris.csv")
#print(c.print_tree())

        

    
