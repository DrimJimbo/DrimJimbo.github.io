Afin de lancer le programme, veuiller run le fichier Controlleur.py
La derniére colonne du fichier csv devras t'être la cible de la classification
Je vous join en plus de mon programme le fichier csv (iris.csv) qui répertorie des plantes en fonction de leur taille (longueur et largeur) de pétale et de sépale
Petit problème d'affichage de l'arbre dans la fenêtre, pour mieux visualiser l'arbre il est aussi afficher dans la console
 
