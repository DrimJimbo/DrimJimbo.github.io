# import 
from tkinter import *
from tkinter.filedialog import *
from typing import List,Union,Dict
from modele import *

# Class Interface - Implemente l'interface graphique du projet 
class Interface():

    def __init__(self,width : int,height : int,title : str,color : str) -> None:
        """
        Builder of Interface class
        Interface, Int(width - width of window), Int(height - height of window), Str(title - title of window), Str(color - color of bg ) -> Interface
        """
        self.filePath = None
        self.goodPath = False
        self.color = color
        self.title = title
        self.width = width
        self.height = height
        # Fenetre principâl
        self.window = Tk() # init window 
        self.window.title(title) # title of window
        self.window.geometry(str(width)+"x"+str(height)) # size of window
        self.window.minsize(720,480) # init minsize of window
        self.window.config(bg=color) # change the background color
        # frameInfo
        self.frameInfo = Frame(self.window,bg=color)
        self.frameInfo.pack()
        # labelInfo
        self.labelInfo = Label(self.frameInfo,text="Infomation",bg = color,fg="white")
        self.labelInfo.pack()
        # labelCart
        textCart = "Veuiler vérifier que votre fichier '.csv' est addapté. De plus la dernière colonne de votre fichier devras être la cible de la classification.\nLe maximun de profondeur pour l'arbre de décison est definis a 5" 
        self.labelCart = Label(self.frameInfo,text = textCart,fg="white",bg=color)
        self.labelCart.pack()
        # frameMiddle
        self.frameMiddle = Frame(self.window,bg=color,border=2,relief=SUNKEN,width=300,height=300)
        self.frameMiddle.pack(expand=YES,fill=X)
        # labelChoose
        self.labelChoose = Label(self.frameMiddle,text="Choose a file : ",bg=color,fg="white",font=("Courier New ",10))
        self.labelChoose.pack()
        # buttonChoose
        self.buttonChoose = Button(self.frameMiddle,text="select file",bg=color,fg="white",command=self.clickOnButtonChoose,font=("Courier New ",10))
        self.buttonChoose.pack(pady=10)
        # labelFile
        self.labelFile = None
        # selectAlgo
        self.textSelect = StringVar(value="choose Algo")
        self.selectAlgo = OptionMenu(self.frameMiddle,self.textSelect,*["CART",])
        self.selectAlgo.pack()
        # buttonValide
        self.buttonValide = Button(self.frameMiddle,text="Validate",bg=color,fg="white",command=self.validate)
        self.buttonValide.pack()
        self.window.mainloop() # start of window 


    def clickOnButtonChoose(self) -> None:
        """
        Choose a file in PC and add a label 
        Interface -> None
        """
        if(self.labelFile != None):
            self.labelFile.destroy() # delete labelFile
            self.labelFile = None
        self.filePath = askopenfilename(title="Select a file") # choose file with window
        print(self.filePath)
        self.nameFile = self.getNamePath(self.filePath) # extract name file in path file
        self.extensionFile = self.getExtensionFile(self.nameFile) # extract the extention of the file 
        if self.extensionFile == ".csv":
            # labelFile
            self.labelFile = Label(self.frameMiddle,text=self.nameFile,bg=self.color,fg="white",font=("Courier New ",10))
            self.labelFile.pack(before=self.buttonChoose)
            self.goodPath = True
        else :
            # labelFile
            text = "This file is not a csv file. Thank you to select a other file ! "
            self.labelFile = Label(self.frameMiddle,text=text,bg=self.color,fg="white",font=("Courier New ",10))
            self.labelFile.pack(before=self.buttonChoose)
            self.goodPath = False

    def getNamePath(self,filePath : str) -> str:
        """
        Extract file name of the filePath
        Str(filePath - Path of file) -> Str(res - file name)
        """
        res = ""
        for i in filePath :
            if(i == "/"):
                res = ""
            else :
                res += i
        return res
    
    def getExtensionFile(self,file : str) -> str:
        """
        Extract extension of the file
        Str(file - file name) -> Str(res - extension of the file [.txt])
        """
        res =""
        for i in file:
            if "." in res :
                res +=i
            if i == ".":
                res =  "."
        return res 

    def getPathFile(self) -> str:
        """
        Return the path file
        Interface -> Str(self.filePath)
        """
        return self.filePath
    
    def validate(self):
        """
        Activate algo choose by user
        Interfarce -> None
        """
        #windowTree
        self.windowTree = Tk()
        self.windowTree.title(self.title) # title of window
        self.windowTree.geometry(str(self.width)+"x"+str(self.height)) # size of window
        self.windowTree.minsize(720,480) # init minsize of window
        self.windowTree.config(bg=self.color) # change the background color
        #labelTree
        self.labelTree = None
        if self.labelTree != None:
            self.labelTree.destroy()
        if self.goodPath == False :
            text = "Change file !!!!!"
        else :
            self.csvFile = CSVFile(self.filePath)
            if self.textSelect.get() == "CART" :
                text = self.csvFile.print_tree()
            elif self.textSelect.get() == "RF":
                text = "Sorry ! RF is not exist :'("
            else :
                text = "Choose a Algo !!!!!!"
        print(self.csvFile.print_tree())
        self.labelTree = Label(self.windowTree,text=text,bg=self.color,fg="white",font=("Courier New ",7))
        self.labelTree.pack()
        self.windowTree.mainloop()
    



