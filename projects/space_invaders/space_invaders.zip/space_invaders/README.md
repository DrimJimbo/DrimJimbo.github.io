# Space Invaders - Projet C (Architecture MVC & SDL3)

## Auteurs : Billaud Ryan, Cavenaile Aymerik, Fouet Quentin

Ce projet est une implémentation complète du jeu **Space Invaders** en langage C. Il repose sur une séparation stricte entre la logique métier, la gestion des entrées et l'affichage (Pattern **MVC**). Le jeu propose une progression par manches avec une difficulté croissante.

## Points Forts
* **Triple Moteur de Rendu** : Support du mode Console (ASCII), Ncurses et graphique via **SDL3**.
* **Difficulté Évolutive** : À chaque manche, la vitesse des ennemis augmente et leur cadence de tir s'accélère.
* **Système de Collision Dynamique** : Gestion précise des projectiles entre les ennemis, le héros et les boucliers destructibles.
* **Debug & Performance** : Cible `valgrind` incluse dans le Makefile pour la gestion de la mémoire.

## Architecture du Projet
Le code est organisé de manière modulaire dans le dossier `src/`:
* **Model (`src/model/`)** : Gestion des entités (coordonnées, points, vies) et de la boucle logique du jeu.
* **View (`src/view/`)** : Implémentations graphiques (SDL3 avec textures PNG), semi-graphiques (Ncurses avec couleurs) et textuelles.
* **Controller (`src/controller/`)** : Abstraction des entrées clavier pour chaque mode (Console, Ncurses, SDL3).

## Installation et Compilation

### Prérequis
* `gcc` et `make`.
* Bibliothèques : `SDL3`, `SDL3_image`, `SDL3_ttf` et `ncurses`.

### Compilation
Pour générer l'exécutable `space-invaders`, lancez simplement :
```bash
make

```

Pour vérifier les fuites mémoire avec Valgrind :

```bash
make valgrind

```

## Comment Jouer ?

Au lancement, le programme vous demande de choisir votre mode d'affichage:

1. **Console** : Mode ASCII pur. (Premier test fait)
2. **Ncurses** : Mode terminal avec couleurs et rafraîchissement fluide.
3. **SDL** : Mode graphique avec sprites chargés depuis le dossier `assets/`.

### Commandes

* **Q** : Déplacer à Gauche.
* **D** : Déplacer à Droite.
* **Espace** : Tirer.
* **Échap** : Quitter le jeu (en mode SDL et Ncurses).
* **P** : Mettre le jeu en pause/resume.
* **Ctrl + c** : Quitter le jeu (en mode Console).

## Détails Techniques

* **IA des Ennemis** : Les ennemis tirent de manière aléatoire, mais uniquement si aucun autre ennemi ne se trouve devant eux dans la même colonne pour éviter les tirs "amis".
* **Gestion SDL3** : Utilisation des nouvelles API `SDL_FRect` et `SDL_RenderTexture` pour un rendu moderne et précis.
* **Système de Score** :
    * Ennemi du haut : 500 pts.
    * Ennemi du milieu : 250 pts.
    * Ennemi du bas : 125 pts.
* **Sprites** : La plupart des sprites utilisés ont été trouvés sur [ce site](https://opengameart.org/content/assets-for-a-space-invader-like-game), les autres (shield, tir) on été fait par nos soins sur [Piskel](https://www.piskelapp.com/)
Le font ttf a été trouvé sur [ce site](https://www.dafont.com/fr/search.php?q=pixel)
---

*Projet réalisé dans le cadre du module de Programmation C Avancé*