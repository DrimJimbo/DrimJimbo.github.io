#include "controller.h"

/**
 * @brief permet de lire un caractére pour la vue console
 * @return le caratére qui est appuyé par l'utilisateur
 */
char lireCaractereConsole(){
    struct termios oldt, newt;
    int oldf;
    int ch;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);

    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if (ch != EOF) {
        return ch;
    }
    return 0;
}

/**
 * @brief permet de bouger le hero dans la vue console
 * @return void
 */
void mvDirection(Entity * hero){
    char ch;
    if((ch = lireCaractereConsole())){
        if (ch == 'q') mvHero(hero, GAUCHE);
        if (ch == 'd') mvHero(hero, DROITE);
        if (ch == ' ') shooter(hero);
    }
}

/**
 * @brief permet de bouger le hero dans la vue ncurse
 * @param hero Pointeur vers le héro
 * @param ch Le caractère déjà lu par le contrôleur principal
 */
void mvDirectionNcurse(Entity * hero, int ch){
    // Sécurité : si pas de touche ou erreur, on ne fait rien
    if (ch == ERR)
        return;

    switch (ch) {
        case 'q':
            mvHero(hero, GAUCHE);
            break;
        case 'd':
            mvHero(hero, DROITE);
            break;
        case ' ':
            shooter(hero);
            break;
        default:
            break;
    }
}

/* ================================================= */
/* =============== CONTROLLER UNIQUE =============== */
/* ================================================= */

static InputMode currentMode = INPUT_CONSOLE;

/**
 * @brief initialise le controller selon le mode choisi
 * @param mode type de backend
 */
void controllerInit(InputMode mode){
    currentMode = mode;
    if (mode == INPUT_SDL) {
        if (SDL_InitSubSystem(SDL_INIT_EVENTS) != 0) {
             printf("Erreur Init Events: %s\n", SDL_GetError());
        }
    }
}

/**
 * @brief libère les ressources du controller
 */
void controllerQuit(void){
    if (currentMode == INPUT_SDL) {
        SDL_QuitSubSystem(SDL_INIT_EVENTS);
    }
}

/**
 * @brief met à jour les entrées utilisateur
 * @param hero pointeur vers le hero
 * @param running permet d'arrêter la boucle de jeu
 */
void controllerUpdate(Entity *hero, int *running){
    
    // --- MODE CONSOLE ---
    if (currentMode == INPUT_CONSOLE) {
        mvDirection(hero);
    }
    
    // --- MODE NCURSES ---
    else if (currentMode == INPUT_NCURSE) {
        int ch = getch(); 
        
        if (ch == 27) { // 27 est le code ASCII de ESC
             *running = 0;
        }

        mvDirectionNcurse(hero, ch);
    }
    
    // --- MODE SDL ---
    else if (currentMode == INPUT_SDL) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            
            if (event.type == SDL_EVENT_QUIT) {
                *running = 0;
            }
            else if (event.type == SDL_EVENT_KEY_DOWN) {
                switch (event.key.key) {
                    case 'q':
                        mvHero(hero, GAUCHE);
                        break;
                    case 'd':
                        mvHero(hero, DROITE);
                        break;
                    case SDLK_SPACE:
                        shooter(hero);
                        break;
                    case SDLK_ESCAPE:
                        *running = 0;
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
