#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <stdio.h>
#include <termios.h>
#include <fcntl.h> 
#include <unistd.h>
#include <ncurses.h>
#include <SDL3/SDL.h>

#include "../model/entity.h"
#include "../model/game.h"

/**
 * @enum DIRECTION
 * @brief direction, droite ou gauche , le hero ne pouvant pas se déplacer de haut en bas 
 */
typedef enum { 
    DROITE = 1 , //!< incrémente x de 1
    GAUCHE = -1 //!< décrémente x de 1
}DIRECTION;

/**
 * @enum InputMode
 * @brief type de backend pour la gestion des entrées utilisateur
 */
typedef enum {
    INPUT_CONSOLE,
    INPUT_NCURSE,
    INPUT_SDL
} InputMode;

/**
 * @brief permet de lire un caractére pour la vue console
 * @return le caratére qui est appuyé par l'utilisateur
 */
char lireCaractereConsole(void); 

/**
 * @brief permet de bouger le hero dans la vue console
 * @return void
 */
void mvDirection(Entity * hero);

/**
 * @brief permet de bouger le hero dans la vue ncurse
 * @param hero pointeur vers le hero
 * @param ch le caractère (touche) reçu depuis le contrôleur principal
 */
void mvDirectionNcurse(Entity * hero, int ch);

/**
 * @brief initialise le controller selon le mode d'entrée
 * @param mode type de backend (console / ncurse / sdl)
 */
void controllerInit(InputMode mode);

/**
 * @brief met à jour les entrées utilisateur
 * @param hero pointeur vers le hero
 * @param running permet d'arrêter la boucle de jeu
 */
void controllerUpdate(Entity *hero, int *running);

/**
 * @brief libère les ressources du controller
 */
void controllerQuit(void);

#endif
