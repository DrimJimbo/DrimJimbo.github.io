#include "view/console.h"
#include "view/ndisplay.h"
#include "view/sdl_display.h"
#include <stdio.h>

int main(){
    int vue = 0;
    printf("1. Vue en mode console\n");
    printf("2. vue en mode ncurse\n");
    printf("3. en mode SDL\n");
    printf("Choisissez un mode (1,2 ou 3): ");
    scanf("%d",&vue);

    switch (vue)
    {
        case 1:
            gameConsole();
            break;
        case 2:
            gameNcurse();
            break;
        case 3:
            gameSDL();
            break;
        default:
            break;
    }
}
