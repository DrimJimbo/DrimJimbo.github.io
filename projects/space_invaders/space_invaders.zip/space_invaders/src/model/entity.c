#include "entity.h"
#include <stdlib.h>

Entity * tabEntity[MAX_ENTITY];
int nb_Entity = 0;

void shooter(Entity  * e){
    if(e->shoot == 0){ // si l'entité n'est pas entrain de shooter
        // creation du shoot
        e->shoot = 1;
        Entity * s = malloc(sizeof(Entity));
        s->type = ENTITY_BULLET;
        s->lives = 1;
        s->model = e->type == ENTITY_ENNEMIE ? " ¡ " : " ! ";
        s->shoot = 0;
        s->width = 1;
        s->x = e->x;
        s->y = e->type == ENTITY_ENNEMIE ? e->y + 1 : e->y -1; 
        s->point = 0;
        s->vx = 0;
        s->vy = e->type == ENTITY_ENNEMIE ? 1 : -1;
        s->shooter = e;
        tabEntity[nb_Entity++] = s;
    }
}

int haveTouch(Entity * e1 , Entity * e2){
    return (e1->x == e2->x) && (e1->y == e2->y);  //renvoie 1 si e1 et e2 se touche
}

void changeCoordonate(Entity * e, int x, int y){
    e->x = e->x+x;
    e->y = e->y+y;
}