#ifndef ENTITY_H
#define ENTITY_H

/**
 * @def MAX_ENTITY
 * @brief le maximun d'entite dans tabEntity
 */
#define MAX_ENTITY 100


/**
 * @enum EntityType
 * @brief les différents types d'entité 
 */
typedef enum EntityType{
    ENTITY_ENNEMIE,
    ENTITY_HEROE,
    ENTITY_BULLET,
    ENTITY_SHIELD
}EntityType;
 
/**
 * @struct Entity
 * @brief représente un entité
 */
typedef struct Entity{
    int x; //!< coordonate x
    int y; //!< coordonate y
    int vx; //!< velocity (1/0/-1)
    int vy; //!< velocity (1/0/-1)
    char *model; //!< display of entity
    int width; //!< width of display 
    int lives; //!< number of lives  
    int shoot; //!< bool, true if entity shoot and false else
    int point; //!< point of entity
    struct Entity * shooter; //!< entity who has shoot
    EntityType type; //!< type of entity
}Entity;

// tabEntity
extern Entity * tabEntity[MAX_ENTITY];
extern int nb_Entity ;

/**
 * @brief initialisation de tabEntity
 * @param tabEntity , pointeur vers le tableau des entités
 * @return void
 */
void initTabEntity(Entity * tabEntity[MAX_ENTITY]);

/**
 * @brief permet au entity de tirer
 * @param e pointeur vers une entité
 * @return void
 */
void shooter(Entity * e);

/**
 * @brief permet de savoir si deux entity se touche 
 * @param e1 pointeur vers une entité
 * @param e2 pointeur vers une entité
 * @return int 1->true 0->false
 */
int haveTouch(Entity * e1 , Entity * e2);

/**
 * @brief permet de changer les coordonée x et y d'une entity
 * @param e pointeur vers une entité
 * @param x nouvelle coordonnée x de l'entité
 * @param y nouvelle coordonnée y de l'entité 
 * @return void
 */
void changeCoordonate(Entity * e, int x, int y);
#endif