#include "game.h"

int score = 0;
int nbMv = 0;
int mv = 25;
int chanceTir = 25;
int lifeEntity = 1;
int nbManche = 1;

void createShieldPart(Entity * tabEntity[MAX_ENTITY], int x, int y) {
    Entity * e = malloc(sizeof(Entity));
    if (!e) return; 

    e->lives = 3;
    e->model = " # ";
    e->point = 0;
    e->shoot = 1;
    e->shooter = NULL;
    e->type = ENTITY_SHIELD;
    e->vx = 0;
    e->vy = 0;
    e->width = 1;
    e->x = x;
    e->y = y;

    tabEntity[nb_Entity++] = e;
}

void creationBouclier(Entity * tabEntity[MAX_ENTITY]){
    int baseY = MAX_Y - 6;

    for(int center = 5; center < 22; center += 7) {
        createShieldPart(tabEntity, center, baseY);
        createShieldPart(tabEntity, center - 1, baseY + 1);
        createShieldPart(tabEntity, center,     baseY + 1);
        createShieldPart(tabEntity, center + 1, baseY + 1);
        createShieldPart(tabEntity, center - 1, baseY + 2);
        createShieldPart(tabEntity, center + 1, baseY + 2);
    }
}

void initTable(Entity * tab[MAX_Y][MAX_X], Entity * tabEntity[MAX_ENTITY], int nb){
    for(int i = 0 ; i < MAX_Y; i++){
        for(int j = 0 ; j < MAX_X ; j++){
            tab[i][j] = NULL;
        }
    }
    for(int i = 0 ; i < nb ; i++){
        Entity * e = tabEntity[i];
        if(e->y >= 0 && e->y < MAX_Y && e->x >= 0 && e->x < MAX_X) {
            tab[e->y][e->x] = e;
        }
    }
}

void initTabEntity(Entity * tabEntity[MAX_ENTITY]){
    nb_Entity = 0;

    for(int i = 0 ; i<10;i++){
        Entity * e = malloc(sizeof(Entity));
        e->lives = lifeEntity;
        e->model = "O^O";
        e->point = 500;
        e->shoot = 0;
        e->type = ENTITY_ENNEMIE;
        e->width = 3;
        e->x = i;
        e->y = 0;
        e->vx = 1;
        e->vy = 1;
        e->shooter = NULL;
        tabEntity[nb_Entity++] = e; 
    }
    for(int i = 0 ; i<10;i++){
        Entity * e = malloc(sizeof(Entity));
        e->lives = lifeEntity;
        e->model = "\\O/";
        e->point = 250;
        e->shoot = 0;
        e->type = ENTITY_ENNEMIE;
        e->width = 3;
        e->x = i;
        e->y = 1;
        e->vx = 1;
        e->vy = 1;
        e->shooter = NULL;
        tabEntity[nb_Entity++] = e; 
    }
    for(int i = 0 ; i<10;i++){
        Entity * e = malloc(sizeof(Entity));
        e->lives = lifeEntity;
        e->model = "^B^";
        e->point = 125;
        e->shoot = 0;
        e->type = ENTITY_ENNEMIE;
        e->width = 3;
        e->x = i;
        e->y = 2;
        e->vx = 1;
        e->vy = 1;
        e->shooter = NULL;
        tabEntity[nb_Entity++] = e; 
    }

    creationBouclier(tabEntity);

    Entity * e = malloc(sizeof(Entity));
    e->lives = 3;
    e->model = "-I-";
    e->point = 0;
    e->shoot = 0;
    e->type = ENTITY_HEROE;
    e->width = 3;
    e->x = 0;
    e->y=MAX_Y-2;
    e->vx = 1;
    e->vy = 0;
    e->shooter = NULL;
    tabEntity[nb_Entity++] = e;
}

void updateEntity(Entity * tabEntity[MAX_ENTITY]){

    int newTab = 0;
    Entity * newTabEntity[MAX_ENTITY];
    for(int i = 0 ; i<nb_Entity ; i++){
        if(tabEntity[i]->lives == 0){
            free(tabEntity[i]);
        }
        else if(tabEntity[i]->lives > 0){
            newTabEntity[newTab++] = tabEntity[i];
        }
    }
    nb_Entity = newTab;
    for(int i = 0;i<newTab;i++){
        tabEntity[i] = newTabEntity[i];
    }
}

void deplaceEnnemie(Entity * tabEntity[MAX_ENTITY]){
    int bool = 0;
    for(int i = 0 ; i<nb_Entity ; i++){
        if(tabEntity[i]->type == ENTITY_ENNEMIE){
            if((tabEntity[i]->x == MAX_X-1 && tabEntity[i]->vx == 1) || (tabEntity[i]->x == 0 && tabEntity[i]->vx == -1)){
                bool = 1; // permet de savoir si un entité a atteint les bordure du jeu
            }
        }
    }
    if(bool){ // si c'est le cas on incrémente le y et on change vx en -vx
        for(int i = 0 ; i<nb_Entity ; i++){
            if(tabEntity[i]->type == ENTITY_ENNEMIE){
                tabEntity[i]->y += tabEntity[i]->vy;
                tabEntity[i]->vx = -tabEntity[i]->vx;
            }
        }
    }
    else{// on bouge de vx les ennemies
        for(int i = 0 ; i<nb_Entity ; i++){
            if(tabEntity[i]->type == ENTITY_ENNEMIE){
                tabEntity[i]->x += tabEntity[i]->vx;
                if(tabEntity[i]->x > MAX_X - 1){
                    tabEntity[i]->x = MAX_X -1;
                }
                else if(tabEntity[i]->x < 0){
                    tabEntity[i] = 0;
                }
            }
        }
    }
}

void deplaceBullet(Entity * tabEntity[MAX_ENTITY]){
    // Pour tout les entity dans tabEntity
    for(int i = 0 ; i<nb_Entity ; i++){
        if(tabEntity[i]->type == ENTITY_BULLET){
            tabEntity[i]->y += tabEntity[i]->vy; // si entity de type Bullet alors on déplace
            if(tabEntity[i]->y < 0 || tabEntity[i]->y > MAX_Y-1 ){ // si y de bullet est inférieur a 0 ou supérieur à MAX_Y-1 alors on le supprime
                tabEntity[i]->lives = 0;
                tabEntity[i]->shooter->shoot = 0;
            }
            else{// sinon on regarde pour chaque entity si bullet et l'entité se touche
                for(int j = 0 ; j<nb_Entity;j++){
                    if(i != j && haveTouch(tabEntity[i],tabEntity[j])){ // si c'est le cas on enléve un vie au 2 entity
                        tabEntity[j]->lives--;
                        tabEntity[i]->lives--;
                        
                        if(tabEntity[i]->shooter != NULL)
                            tabEntity[i]->shooter->shoot = 0;

                        
                        if(tabEntity[j]->type == ENTITY_BULLET && tabEntity[j]->shooter != NULL){
                            tabEntity[j]->shooter->shoot = 0;
                        }
                        
                        if(tabEntity[j]->type == ENTITY_ENNEMIE) score+=tabEntity[j]->point; // si c'est un ennemie qui a été toucher on augmente le score
                    }
                }
            }
        }
    }
    updateEntity(tabEntity);
}

int isFinish(Entity * tabEntity[MAX_ENTITY],Entity * hero){
    int bool = (hero->lives <= 0 ? 1 : 0); // nb de vie du hero inferieur a 0 -> 1 donc fini
    if(bool) return 1;
    for(int i = 0 ; tabEntity[i] != hero && i < nb_Entity ; i++ ){
        if(tabEntity[i]->type == ENTITY_ENNEMIE && tabEntity[i]->y == hero->y) return 1; // on regarde si un ennmie est au même y que le héro 
    }
    return 0;
}

void mvHero(Entity * hero,  int direction){
    if(direction < 0){
        if(hero->x+(direction * hero->vx) < 0) hero->x = 0;
        else hero->x += (direction * hero->vx);
    }
    if(direction > 0){
        if(hero->x+(direction * hero->vx) > MAX_X-1) hero->x = MAX_X-1;
        else hero->x += (direction * hero->vx);
    }
}

int shootPossible(int index){
    int x = tabEntity[index]->x;
    int y = tabEntity[index]->y;
    for(int i = 0 ; i<nb_Entity;i++){
        if(i!= index && tabEntity[i]->type == ENTITY_ENNEMIE && tabEntity[i]->x == x && tabEntity[i]->y > y){ // si une entité a le même x que l'entoté qui tire et le y plus grand (endessous de l'entité qui tire ) alors tire impossible
            return 0;
        }
    }
    return 1;
}

void shootEntity(Entity * tabEntity[MAX_ENTITY]){
    srand(time(NULL));
    for(int i = 0 ; i<nb_Entity ; i++){
        if(tabEntity[i]->type == ENTITY_ENNEMIE && shootPossible(i)){
            int r = rand() % chanceTir ;
            if(r == 1){
                shooter(tabEntity[i]);
            }
        }
    }
}

void destroyEntity(Entity * tabEntity[MAX_ENTITY], Entity * except){
    for(int i = 0; i < nb_Entity; i++){
        if(tabEntity[i] != NULL){
            // On ne free QUE si ce n'est pas l'entité qu'on veut garder
            if (tabEntity[i] != except) {
                free(tabEntity[i]);
            }
            // On met le pointeur du tableau à NULL dans tous les cas pour nettoyer le tableau
            tabEntity[i] = NULL;
        }
    }
    // Si on a gardé le héros, nb_Entity ne doit pas forcément être 0, 
    // mais initTabEntity va le reset juste après de toute façon.
}

void nextManche(Entity * tabEntity[MAX_ENTITY] , Entity * hero ){
    for(int i = 0 ; i<nb_Entity ; i++){
        if(tabEntity[i]->type == ENTITY_ENNEMIE){
            return ; // Il reste des ennemis
        }
    }

    destroyEntity(tabEntity, hero);

    Entity * newTabEntity[MAX_ENTITY];
    initTabEntity(newTabEntity);

    for(int i = 0 ; i<nb_Entity ; i++){
        if(newTabEntity[i]->type == ENTITY_HEROE){
            free(newTabEntity[i]); 
            
            newTabEntity[i] = hero;
            
            hero->x = 0; 
            hero->y = MAX_Y - 2;
        }
        tabEntity[i] = newTabEntity[i];
    }

    nbManche++;
    mv -= 2;
    chanceTir = chanceTir - 3 < 1 ? 1 : chanceTir-3; 
    lifeEntity += 1;
}