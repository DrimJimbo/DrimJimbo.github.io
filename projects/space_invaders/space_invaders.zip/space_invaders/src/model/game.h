#ifndef GAME_H
#define GAME_H
#include "entity.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/**
 * @def MAX_X
 * @brief maximun de colonnes dans table
 */
#define MAX_X 25

/**
 * @def MAX_Y
 * @brief maximun de lignes dans table
 */
#define MAX_Y 20

extern int score; // score du joueur
extern int nbMv; // nb de frame 
extern int mv; //nb de frame, tout les mv frame les ennemies bouge, permet d'avoir une usleep plus court et donc un jeu plus fluide
extern int chanceTir; // chance de tir d'un ennemie 
extern int lifeEntity; // nb de vie par entity
extern int nbManche; // nb de manche 

/**
 * @brief initialise tab (tableau de jeu)
 * @param tab pointeur vers tab (tableau de jeu)
 * @param tabEntity pointeur vers tabEntity (tableau de entité)
 * @return  void
 */
void initTable(Entity * tab[MAX_Y][MAX_X] , Entity * tabEntity[MAX_ENTITY] , int nb);

/**
 * @brief creation et ajout des bouclier dans tabEntity
 * @param tabEntity pointeur vers le tabealu des entité
 * @return void 
 */
void creationBouclier(Entity * tabEntity[MAX_ENTITY]);

/**
 * @brief initialise tabEntity (tableau des entités)
 * @param tabEntity pointeur vers le tableau des entités
 * @return void
 */
void initTabEntity(Entity * tabEntity[MAX_ENTITY]);

/**
 * @brief met à jours le tableau de jeu
 * @param tab pointeur vers tab (tableau de jeu)
 * @return void
 */
void updateTable(Entity * tab[MAX_Y][MAX_X]);

/**
 * @brief permet de déplacer les entity ennemie
 * @param tabEntity pointeur vers tableau des entité
 * @return void
 */
void deplaceEnnemie(Entity * tabEntity[MAX_ENTITY]);

/**
 * @brief deplace les tire 
 * @param tabEntity pointeur vers tableau des entité
 * @return void
 */
void deplaceBullet(Entity * tabEntity[MAX_ENTITY]);

/**
 * @brief permet de savoir si le jeu est terminé (lorsque un ennemie se trouve sur le même y que le joueur )
 * @param tabEntity pointeur vers tableau des entité
 * @param hero pointeur vers le hero (joueur) 
 * @return int 1->true 0->false
 */
int isFinish(Entity * tabEntity[MAX_ENTITY],Entity * hero);

/**
 * @brief permet de bouger le hero
 * @param hero pointeur vers le hero (joueur)
 * @param direction -1->gauche 1->droite
 * @return void
 */
void mvHero(Entity * hero,  int direction);

/**
 * @brief permet de savoir si le tire est possible
 * @param index indice de l'entité qui veux tirer dans tabEntity
 * @return int 1->true 0->false
 */
int shootPossible(int index);

/**
 * @brief permet de faire tirer les ennemie
 * @param tabEntity pointeur vers tableau des entités
 * @return void
 */
void shootEntity(Entity * tabEntity[MAX_ENTITY]);

/**
 * @brief libérer esapce mémoire des entités
 * @param tabEntity pointeur vers le tableau des entité
 * @return void
 */
void destroyEntity(Entity * tabEntity[MAX_ENTITY], Entity * except);

/**
 * @brief permet d'incrementer nbManche et d'autre variable global si une manche est terminé 
 * @param tabEntity pointeur vers le tableau des entité
 * @param hero pointeur vers le héro 
 * @return void
 */
void nextManche(Entity * tabEntity[MAX_ENTITY],Entity * hero);

typedef enum {
    MENU_START,
    GAME_PLAY,
    GAME_PAUSE,
    GAME_GAMEOVER
} GameState;

#endif