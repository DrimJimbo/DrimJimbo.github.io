#include "console.h"

void displayGameConsole(Entity * tab[MAX_Y][MAX_X],Entity * hero){
   for(int i = 0;i<MAX_Y ;i++){
        for(int j = 0; j<MAX_X ; j++){
            if (tab[i][j] == NULL) printf("   ");
            else printf("%s",tab[i][j]->model);
        }
        printf("\n");
    }
    printf("Score: %d     Manche: %d     Vies:",score,nbManche);
    for(int i = 0; i<hero->lives;i++){
        printf("%s/",hero->model);
    }
    printf("\n");
}

void gameConsole(){
    initTabEntity(tabEntity);
    Entity * tab[MAX_Y][MAX_X];
    initTable(tab,tabEntity,nb_Entity);
    Entity * hero = tabEntity[nb_Entity-1];

    while(!isFinish(tabEntity,hero)){
        mvDirection(hero);
        int ret = system("clear");
        if(ret == -1) printf("Erreur");
        if(nbMv == mv){
            deplaceEnnemie(tabEntity);
            shootEntity(tabEntity);
            deplaceBullet(tabEntity);
            nbMv = 0;
        }
        nextManche(tabEntity,hero);
        initTable(tab,tabEntity,nb_Entity);
        displayGameConsole(tab,hero);
        usleep(16000); // 60 fps
        nbMv++;
    }
    printf("GAME OVER - Score final: %d\n", score);
}