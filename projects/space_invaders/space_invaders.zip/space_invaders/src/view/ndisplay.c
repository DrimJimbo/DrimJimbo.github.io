#include "ndisplay.h"

void displayGameNcurse(Entity * tab[MAX_Y][MAX_X],Entity * hero){
    int k = 1;
    int b = 0;
    for(int i = 0;i<MAX_Y ;i++){
        for(int j = 0; j<MAX_X ; j++){
            if (tab[i][j] == NULL) printw("   ");
            else if(tab[i][j]->type == ENTITY_HEROE){
                attron(COLOR_PAIR(4));
                printw("%s",hero->model);
                attroff(COLOR_PAIR(4));
            }
            else if(tab[i][j]->type == ENTITY_BULLET){
                printw("%s",tab[i][j]->model);
            }
            else if(tab[i][j]->type == ENTITY_SHIELD){
                attron(COLOR_PAIR(5));
                printw("%s",tab[i][j]->model);
                attroff(COLOR_PAIR(5));
            }
            else {
                attron(COLOR_PAIR(k));
                printw("%s",tab[i][j]->model);
                attroff(COLOR_PAIR(k));
                b = 1;
            }
        }
        if(b) k++;
        b = 0;
        printw("\n");
    }
    printw("Score: %d     Manche: %d     Vies:",score,nbManche);
    for(int i = 0; i<hero->lives;i++){
        printw("%s/",hero->model);
    }
    printw("\n");
}

void resetGameNcurse(Entity **hero) {
    destroyEntity(tabEntity, NULL);

    score = 0;
    nbManche = 1;
    nbMv = 0;
    mv = 15;
    chanceTir = 25;
    lifeEntity = 1;

    initTabEntity(tabEntity);
    *hero = tabEntity[nb_Entity - 1];
}

void gameNcurse(){
    // Init Game
    initTabEntity(tabEntity);
    Entity * tab[MAX_Y][MAX_X];
    initTable(tab,tabEntity,nb_Entity);
    Entity * hero = tabEntity[nb_Entity-1];
    // Init window
    initscr();          // Init
    cbreak();
    start_color();
    init_pair(1,COLOR_RED,COLOR_BLACK);
    init_pair(2,COLOR_GREEN,COLOR_BLACK);
    init_pair(3,COLOR_MAGENTA,COLOR_BLACK);
    init_pair(4,COLOR_CYAN,COLOR_BLACK);
    init_pair(5,COLOR_YELLOW,COLOR_BLACK);
    noecho();
    keypad(stdscr, TRUE);
    nodelay(stdscr, TRUE);
    curs_set(0);
    refresh();

    GameState state = MENU_START;
    int ch; 
    int running = 1; 

    while(running){
        
        ch = getch();

        if (ch == 27) running = 0; 

        // ==========================================
        // ETAT 1 : MENU PRINCIPAL
        // ==========================================
        if (state == MENU_START) {
            clear();
            attron(COLOR_PAIR(2));
            mvprintw(MAX_Y/2 - 2, MAX_X/2 - 10, "=== SPACE INVADERS ===");
            attroff(COLOR_PAIR(2));
            mvprintw(MAX_Y/2,     MAX_X/2 - 9, "PRESS ENTER TO START");
            mvprintw(MAX_Y/2 + 2, MAX_X/2 - 8,  "PRESS 'Q' TO QUIT");
            
            if (ch == '\n') state = GAME_PLAY;
            if (ch == 'q') running = 0;
            
            usleep(50000);
            continue;
        }

        // ==========================================
        // ETAT 2 : GAME OVER (NOUVEAU)
        // ==========================================
        if (state == GAME_GAMEOVER) {
            clear();
            
            attron(COLOR_PAIR(1) | A_BOLD);
            mvprintw(MAX_Y/2 - 2, MAX_X/2 - 5, "GAME OVER");
            attroff(COLOR_PAIR(1) | A_BOLD);

            mvprintw(MAX_Y/2,     MAX_X/2 - 8, "FINAL SCORE: %d", score);
            mvprintw(MAX_Y/2 + 2, MAX_X/2 - 10, "PRESS ENTER TO RESTART");
            mvprintw(MAX_Y/2 + 3, MAX_X/2 - 8,  "PRESS 'Q' TO QUIT");
            
            if (ch == '\n') {
                resetGameNcurse(&hero);
                state = GAME_PLAY;
            }
            if (ch == 'q') running = 0;

            usleep(50000);
            continue;
        }

        // ==========================================
        // ETAT 3 : PAUSE
        // ==========================================
        if (ch == 'p') {
            if (state == GAME_PLAY) state = GAME_PAUSE;
            else if (state == GAME_PAUSE) state = GAME_PLAY;
        }

        if (state == GAME_PAUSE) {
            attron(A_BLINK);
            mvprintw(MAX_Y/2, MAX_X/2 - 3, " PAUSE ");
            attroff(A_BLINK);
            refresh();
            usleep(50000);
            continue;
        }

        // ==========================================
        // ETAT 4 : JEU EN COURS (GAME_PLAY)
        // ==========================================
        
        // 1. Inputs Jeu
        mvDirectionNcurse(hero, ch); 

        // 2. Logique Jeu
        if(nbMv % 5 == 0) deplaceBullet(tabEntity);
        
        if(nbMv == mv){
            deplaceEnnemie(tabEntity);
            shootEntity(tabEntity);
            nbMv = 0;
        }

        nextManche(tabEntity,hero);
        
        // ==========================================
        // ETAT 4 : FIN DE PARTIE (GAME_GAMEOVER)
        // ==========================================
        if (isFinish(tabEntity, hero)) {
            state = GAME_GAMEOVER;
            continue;
        }

        initTable(tab,tabEntity,nb_Entity);
        clear();
        displayGameNcurse(tab,hero);
        refresh();
        
        usleep(16000);
        nbMv++;
    }   
    
    destroyEntity(tabEntity, NULL);
    endwin();
}