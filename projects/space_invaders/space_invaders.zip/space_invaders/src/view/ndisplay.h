#define _XOPEN_SOURCE 500

#include "../model/game.h"
#include "../controller/controller.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ncurses.h>
/**
 * @brief permet l'affichage du jeu en mode ncurse
 * @param tab pointeur vers le tableau du jeu
 * @param hero pointeur vers le hero (joueur)
 * @return void
 */
void displayGame(Entity * tab[MAX_Y][MAX_X],Entity * hero);

/**
 * @brief boucle du jeu
 * @param void
 * @return void
 */
void gameNcurse();