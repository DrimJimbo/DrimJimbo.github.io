#include "../model/game.h"
#include "../controller/controller.h"
#include <SDL3/SDL.h>
#include <SDL3_image/SDL_image.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>

#define TILE_SIZE 48.0f 
#define WINDOW_WIDTH  (MAX_X * TILE_SIZE)
#define WINDOW_HEIGHT (MAX_Y * TILE_SIZE)

// Macro de chargement texture avec message d'erreur si échec
#define LOAD_TEXTURE(rend, path) ({ \
    SDL_Surface *surf = IMG_Load(path); \
    SDL_Texture *tex = NULL; \
    if (surf) { \
        tex = SDL_CreateTextureFromSurface(rend, surf); \
        SDL_DestroySurface(surf); \
    } \
    if (!tex) printf("Échec chargement sprite : %s\n", path); \
    tex; \
})

// Textures statiques
static SDL_Texture *tex_hero     = NULL;
static SDL_Texture *tex_bullet   = NULL;
static SDL_Texture *tex_shield   = NULL;
static SDL_Texture *tex_enemy[3] = {NULL, NULL, NULL};
static SDL_Texture *tex_menu_start = NULL;
static SDL_Texture *tex_menu_pause = NULL;

// Font globale
static TTF_Font *font = NULL;

void draw_text(SDL_Renderer *renderer, int x, int y, const char *text, SDL_Color color) {
    if (!font || !text) return;

    SDL_Surface *surface = TTF_RenderText_Solid(font, text, 0, color);
    if (surface) {
        SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);
        
        SDL_FRect dst;
        dst.w = (float)surface->w;
        dst.h = (float)surface->h;
        dst.y = (float)y;

        if (x == -1) {
            dst.x = (WINDOW_WIDTH - dst.w) / 2.0f;
        } else {
            dst.x = (float)x;
        }

        SDL_RenderTexture(renderer, texture, NULL, &dst);
        SDL_DestroyTexture(texture);
        SDL_DestroySurface(surface);
    }
}

static SDL_Texture* get_texture_for_entity(Entity *e) {
    switch (e->type) {
        case ENTITY_HEROE:   return tex_hero;
        case ENTITY_BULLET:  return tex_bullet;
        case ENTITY_SHIELD:  return tex_shield;
        case ENTITY_ENNEMIE:
            if (e->point == 500) return tex_enemy[0];
            if (e->point == 250) return tex_enemy[1];
            return tex_enemy[2];
        default: return NULL;
    }
}

void resetGame(Entity **hero_ptr) {
    destroyEntity(tabEntity, NULL);
    score = 0;
    nbManche = 1;
    nbMv = 0;
    mv = 15; // Reset vitesse aussi
    initTabEntity(tabEntity);
    *hero_ptr = tabEntity[nb_Entity - 1];
}

void gameSDL(void) {
    // 1. INIT SDL + TTF
    if (SDL_Init(SDL_INIT_VIDEO) == 0) return;
    if (TTF_Init() == 0) {
        printf("Erreur TTF_Init: %s\n", SDL_GetError());
        return;
    }

    SDL_Window *window = SDL_CreateWindow("Space Invaders Deluxe", (int)WINDOW_WIDTH, (int)WINDOW_HEIGHT, 0);
    if (!window) return;
    SDL_Renderer *renderer = SDL_CreateRenderer(window, NULL);
    if (!renderer) return;

    // 2. CHARGEMENT ASSETS
    tex_hero     = LOAD_TEXTURE(renderer, "assets/hero.png");
    tex_bullet   = LOAD_TEXTURE(renderer, "assets/bullet.png");
    tex_shield   = LOAD_TEXTURE(renderer, "assets/shield.png");
    tex_enemy[0] = LOAD_TEXTURE(renderer, "assets/enemy500.png");
    tex_enemy[1] = LOAD_TEXTURE(renderer, "assets/enemy250.png");
    tex_enemy[2] = LOAD_TEXTURE(renderer, "assets/enemy125.png");
    tex_menu_start = LOAD_TEXTURE(renderer, "assets/menu.png");
    tex_menu_pause = LOAD_TEXTURE(renderer, "assets/pause.png");

    font = TTF_OpenFont("assets/pixel.ttf", 32.0f); 
    if (!font) printf("Erreur chargement police (assets/pixel.ttf) : %s\n", SDL_GetError());

    // 3. VARIABLES
    initTabEntity(tabEntity);
    Entity *hero = tabEntity[nb_Entity - 1];

    int running = 1;
    int nbMvLocal = 0;
    SDL_Event event;
    GameState state = MENU_START;

    char scoreText[50]; 

    while (running) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_EVENT_QUIT) running = 0;
            else if (event.type == SDL_EVENT_KEY_DOWN) {
                if (event.key.key == SDLK_ESCAPE) running = 0;

                switch(state) {
                    case MENU_START:
                        if (event.key.key == SDLK_RETURN) state = GAME_PLAY;
                        break;

                    case GAME_PLAY:
                        if (event.key.key == 'p') state = GAME_PAUSE;
                        else if (event.key.key == 'q') mvHero(hero, GAUCHE);
                        else if (event.key.key == 'd') mvHero(hero, DROITE);
                        else if (event.key.key == SDLK_SPACE) shooter(hero);
                        break;

                    case GAME_PAUSE:
                        if (event.key.key == 'p') state = GAME_PLAY;
                        break;
                    
                    case GAME_GAMEOVER:
                        if (event.key.key == SDLK_RETURN) {
                            resetGame(&hero);
                            nbMvLocal = 0;
                            state = GAME_PLAY;
                        }
                        break;
                }
            }
        }

        // --- LOGIQUE ---
        if (state == GAME_PLAY) {
            if (nbMvLocal % 3 == 0) deplaceBullet(tabEntity);
            if (nbMvLocal == mv) {
                deplaceEnnemie(tabEntity);
                shootEntity(tabEntity);
                nbMvLocal = 0;
            }
            nextManche(tabEntity, hero);
            nbMvLocal++;

            if (isFinish(tabEntity, hero)) {
                state = GAME_GAMEOVER;
            }
        }

        // --- RENDU ---
        
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        
        if (state == GAME_GAMEOVER) {
            SDL_SetRenderDrawColor(renderer, 50, 0, 0, 255);
        }
        
        SDL_RenderClear(renderer);

        if (state == MENU_START) {
            if(tex_menu_start) SDL_RenderTexture(renderer, tex_menu_start, NULL, NULL);
            else {
                 SDL_Color green = {0, 255, 0, 255};
                 draw_text(renderer, -1, WINDOW_HEIGHT/2 - 50, "SPACE INVADERS", green);
                 draw_text(renderer, -1, WINDOW_HEIGHT/2 + 50, "PRESS ENTER", green);
            }
        }
        else if (state == GAME_GAMEOVER) {
            // --- ECRAN GAME OVER ---
            SDL_Color red = {255, 0, 0, 255};
            SDL_Color white = {255, 255, 255, 255};
            SDL_Color yellow = {255, 255, 0, 255};
            
            draw_text(renderer, -1, WINDOW_HEIGHT/3, "GAME OVER", red);
            
            sprintf(scoreText, "FINAL SCORE: %d", score);
            draw_text(renderer, -1, WINDOW_HEIGHT/2, scoreText, yellow);

            draw_text(renderer, -1, WINDOW_HEIGHT/2 + 80, "ENTER TO RESTART", white);
            draw_text(renderer, -1, WINDOW_HEIGHT/2 + 120, "ESC TO QUIT", white);
        }
        else {
            // --- JEU EN COURS (PLAY ou PAUSE) ---
            
            // Entités
            for (int i = 0; i < nb_Entity; i++) {
                SDL_FRect dest = { .x = tabEntity[i]->x * TILE_SIZE, .y = tabEntity[i]->y * TILE_SIZE, .w = TILE_SIZE, .h = TILE_SIZE };
                SDL_Texture *tex = get_texture_for_entity(tabEntity[i]);
                if (tex) SDL_RenderTexture(renderer, tex, NULL, &dest);
                else {
                    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
                    SDL_RenderFillRect(renderer, &dest);
                }
            }

            // --- HUD (INTERFACE) ---

            SDL_Color white = {255, 255, 255, 255};

            // 2. SCORE (BAS GAUCHE)
            sprintf(scoreText, "Score: %d  Manche: %d", score, nbManche);
            draw_text(renderer, 5, WINDOW_HEIGHT - 60, scoreText, white);

            // 3. VIES (BAS DROITE)
            float life_size = TILE_SIZE * 0.6f;
            float padding = 5.0f;
            float total_width = hero->lives * (life_size + padding);
            float start_x = WINDOW_WIDTH - total_width - 10;

            for (int i = 0; i < hero->lives; i++) {
                SDL_FRect lifeRect = { 
                    .x = start_x + i * (life_size + padding), 
                    .y = WINDOW_HEIGHT - life_size - 10,
                    .w = life_size, 
                    .h = life_size 
                };

                if (tex_hero) SDL_RenderTexture(renderer, tex_hero, NULL, &lifeRect);
                else {
                     SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
                     SDL_RenderFillRect(renderer, &lifeRect);
                }
            }

            // 4. PAUSE
            if (state == GAME_PAUSE) {
                if(tex_menu_pause) {
                    float w = 400, h = 150;
                    SDL_FRect rect = { (WINDOW_WIDTH - w)/2, (WINDOW_HEIGHT - h)/2, w, h };
                    SDL_RenderTexture(renderer, tex_menu_pause, NULL, &rect);
                } else {
                    draw_text(renderer, -1, WINDOW_HEIGHT/2, "PAUSE", white);
                }
            }
        }

        SDL_RenderPresent(renderer);
        SDL_Delay(16);
    }

    // --- NETTOYAGE ---
    if(font) TTF_CloseFont(font);
    TTF_Quit();
    if (tex_menu_start) SDL_DestroyTexture(tex_menu_start);
    if (tex_menu_pause) SDL_DestroyTexture(tex_menu_pause);
    
    if (tex_hero) SDL_DestroyTexture(tex_hero);
    if (tex_bullet) SDL_DestroyTexture(tex_bullet);
    if (tex_shield) SDL_DestroyTexture(tex_shield);
    for(int i=0; i<3; i++) if(tex_enemy[i]) SDL_DestroyTexture(tex_enemy[i]);

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}