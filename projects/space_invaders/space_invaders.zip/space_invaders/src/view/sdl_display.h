#ifndef SDL_DISPLAY_H
#define SDL_DISPLAY_H

/**
 * @brief boucle du jeu en mode SDL
 */
void gameSDL(void);

#endif
